import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { RawLine, Settings, SongMeta } from "./lib/types";
import { parseSubtitleFile, takeWordTimes, type ParseResult, type WordTime } from "./lib/parsers";
import { buildLyricLines } from "./lib/syllabify";
import { buildChart } from "./lib/chart";
import { parseChartFile, type ImportedChart } from "./lib/chartImport";
import { DEMO_LRC } from "./lib/demo";
import { clamp, fmtClock } from "./lib/format";
import { Reveal } from "./components/Reveal";
import { InputPanel, type LoadedInfo } from "./components/InputPanel";
import { SyncConsole } from "./components/SyncConsole";
import { CueSheet } from "./components/CueSheet";
import { SyllableEditor } from "./components/SyllableEditor";
import { PreviewStage } from "./components/PreviewStage";
import { OutputConsole } from "./components/OutputConsole";
import { Reference } from "./components/Reference";

const TICKER = [
  "SRT IN",
  "00:08.00 ▸ STREET-LIGHTS",
  "LRC IN",
  "[00:12.34] ▸ FLICK-ER",
  "SYLLABLES OUT",
  'E "lyric" "Hel"',
  'E "lyric" "-lo"',
  "HYPHEN CONTINUATIONS",
  'LINE-END HOLD "+"',
  "TICKS @ 192 / BEAT",
  "BPM → TS 120000",
  "SECTIONS ▸ PRACTICE MENU",
  "[Events] OUT",
  ".CHART SKELETON",
];

function Logo() {
  return (
    <svg viewBox="0 0 32 32" className="h-9 w-9 flex-none drop-shadow-[0_0_10px_rgba(255,93,77,0.45)]">
      <path d="M16 2 L29 9 L29 23 L16 30 L3 23 L3 9 Z" fill="#ff5d4d" />
      <path d="M9 19 V13 M13.5 21 V11 M18 18 V14 M22.5 20 V12" stroke="#0d0b11" strokeWidth="2.4" strokeLinecap="round" />
    </svg>
  );
}

export default function App() {
  const [rawLines, setRawLines] = useState<RawLine[] | null>(null);
  const [meta, setMeta] = useState<SongMeta>({});
  const [loaded, setLoaded] = useState<LoadedInfo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [wordTimes, setWordTimes] = useState<Map<string, WordTime[]>>(new Map());
  const [overrides, setOverrides] = useState<Map<string, string>>(new Map());
  const [removed, setRemoved] = useState<Set<string>>(new Set());

  const [settings, setSettings] = useState<Settings>({
    offsetMs: 0,
    bpm: 120,
    tempoMap: null,
    anchors: null,
    resolution: 192,
    holdMs: 3000,
    distMode: "chars",
    hyphenCont: true,
    holdPlus: true,
    sections: true,
    sectionEvery: 4,
  });

  const [timeMs, setTimeMs] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);
  const timeRef = useRef(0);

  // audio sync-check source
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioName, setAudioName] = useState<string | null>(null);
  const [audioDurMs, setAudioDurMs] = useState(0);
  const [volume, setVolume] = useState(0.9);

  // imported .chart (metadata match + event preview)
  const [imported, setImported] = useState<ImportedChart | null>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const [importNotice, setImportNotice] = useState<string | null>(null);

  const lines = useMemo(
    () => (rawLines ? buildLyricLines(rawLines, settings, overrides, removed, wordTimes) : []),
    [rawLines, settings, overrides, removed, wordTimes],
  );

  const chart = useMemo(
    () => (lines.length ? buildChart(lines, settings, meta, loaded?.sourceName ?? "", imported) : null),
    [lines, settings, meta, loaded, imported],
  );

  const totalMs = useMemo(() => {
    const lyricEnd = lines.length ? lines[lines.length - 1].endMs : 0;
    if (audioDurMs > 0) return Math.max(audioDurMs, lyricEnd + 1500);
    return lines.length ? lyricEnd + 3000 : 60000;
  }, [lines, audioDurMs]);

  const stats = useMemo(() => {
    let words = 0;
    let syls = 0;
    for (const l of lines) {
      words += l.words.length;
      for (const w of l.words) syls += w.syllables.length;
    }
    return { words, syls };
  }, [lines]);

  const seek = useCallback(
    (ms: number) => {
      const v = clamp(ms, 0, totalMs);
      timeRef.current = v;
      setTimeMs(v);
      const a = audioRef.current;
      if (a && audioUrl && Number.isFinite(a.duration)) {
        try {
          a.currentTime = Math.min(v / 1000, a.duration);
        } catch {
          /* not seekable yet */
        }
      }
    },
    [totalMs, audioUrl],
  );

  const handleParsed = (res: ParseResult, name: string) => {
    setRawLines(res.lines);
    setMeta(res.meta);
    setLoaded({
      format: res.format,
      count: res.lines.length,
      sourceName: name,
      meta: res.meta,
      notes: res.notes,
    });
    setWordTimes(takeWordTimes());
    setOverrides(new Map());
    setRemoved(new Set());
    setPlaying(false);
    timeRef.current = 0;
    setTimeMs(0);
  };

  const handleClear = () => {
    setRawLines(null);
    setLoaded(null);
    setError(null);
    setOverrides(new Map());
    setRemoved(new Set());
    setPlaying(false);
    timeRef.current = 0;
    setTimeMs(0);
  };

  /* ---------- audio sync-check ---------- */

  const loadAudioFile = (file: File) => {
    const prev = audioRef.current;
    if (prev) {
      prev.pause();
      prev.onloadedmetadata = null;
      prev.onended = null;
    }
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    const url = URL.createObjectURL(file);
    const a = prev ?? new Audio();
    audioRef.current = a;
    a.src = url;
    a.preload = "auto";
    a.volume = volume;
    a.onloadedmetadata = () =>
      setAudioDurMs(Number.isFinite(a.duration) ? a.duration * 1000 : 0);
    a.onended = () => setPlaying(false);
    setAudioUrl(url);
    setAudioName(file.name);
    setAudioDurMs(0);
    setPlaying(false);
    timeRef.current = 0;
    setTimeMs(0);
  };

  const removeAudio = () => {
    const a = audioRef.current;
    if (a) {
      a.pause();
      a.onloadedmetadata = null;
      a.onended = null;
      a.removeAttribute("src");
      a.load();
    }
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    setAudioUrl(null);
    setAudioName(null);
    setAudioDurMs(0);
    setPlaying(false);
  };

  /* ---------- .chart import: match settings + preview events ---------- */

  /** settings edits — hand-editing BPM drops an imported tempo map / anchors */
  const handleSettingsChange = (patch: Partial<Settings>) => {
    const hasSync =
      (settings.tempoMap && settings.tempoMap.length > 0) ||
      (settings.anchors && settings.anchors.length > 0);
    if (patch.bpm !== undefined && hasSync) {
      patch = { ...patch, tempoMap: null, anchors: null };
      setImportNotice(`Tempo map & anchors cleared — using a constant ${patch.bpm} BPM now.`);
    }
    setSettings((s) => ({ ...s, ...patch }));
  };

  const importChartFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const imp = parseChartFile(String(reader.result ?? ""), file.name);
        setImported(imp);
        setImportError(null);

        const patch: Partial<Settings> = {};
        if (imp.resolution) patch.resolution = imp.resolution;
        const validTempos = imp.tempos.filter((t) => Number.isFinite(t.bpm) && t.bpm > 0);
        if (validTempos.length > 1) {
          // real tempo map — tick math will follow every marker
          patch.tempoMap = validTempos;
          patch.bpm = Math.min(400, Math.max(30, Math.round(validTempos[0].bpm * 100) / 100));
        } else if (validTempos.length === 1) {
          patch.tempoMap = null;
          patch.bpm = Math.round(validTempos[0].bpm * 100) / 100;
        }
        patch.anchors = imp.anchors.length > 0 ? imp.anchors : null;
        if (imp.delaySec !== 0) patch.offsetMs = Math.round(-imp.delaySec * 1000);
        setSettings((s) => ({ ...s, ...patch }));

        setMeta((m) => ({
          ...m,
          ...(imp.name ? { title: imp.name } : {}),
          ...(imp.artist ? { artist: imp.artist } : {}),
        }));

        const bits = [
          `${imp.resolution} RES`,
          validTempos.length > 1
            ? `TEMPO MAP ${validTempos.length} MARKERS`
            : validTempos.length === 1
              ? `${Math.round(validTempos[0].bpm * 100) / 100} BPM`
              : null,
          imp.delaySec !== 0 ? `OFFSET ${Math.round(-imp.delaySec * 1000)} ms` : null,
          imp.anchors.length > 0 ? `${imp.anchors.length} ANCHOR${imp.anchors.length > 1 ? "S" : ""}` : null,
        ].filter(Boolean);
        setImportNotice(
          `Settings matched from ${file.name}${bits.length ? " — " + bits.join(" · ") : ""}`,
        );
      } catch (err) {
        setImportError((err as Error).message);
      }
    };
    reader.onerror = () => setImportError("Could not read that file.");
    reader.readAsText(file);
  };

  useEffect(() => {
    const a = audioRef.current;
    if (a) a.volume = volume;
  }, [volume]);

  // boot with the demo LRC so the stage is never dark
  const booted = useRef(false);
  useEffect(() => {
    if (booted.current) return;
    booted.current = true;
    try {
      handleParsed(parseSubtitleFile(DEMO_LRC, "neon-meridian-demo.lrc"), "neon-meridian-demo.lrc");
    } catch {
      /* demo is guaranteed-valid */
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // preview clock — audio-driven when a song is loaded, internal otherwise
  useEffect(() => {
    if (!playing) return;
    const audio = audioRef.current;
    let raf = 0;

    if (audioUrl && audio) {
      if (Math.abs(audio.currentTime * 1000 - timeRef.current) > 60) {
        try {
          audio.currentTime = timeRef.current / 1000;
        } catch {
          /* ignore */
        }
      }
      audio.playbackRate = speed;
      audio.play().catch(() => setPlaying(false));
      const loop = () => {
        const t = audio.currentTime * 1000;
        timeRef.current = t;
        setTimeMs(t);
        if (audio.ended) setPlaying(false);
        raf = requestAnimationFrame(loop);
      };
      raf = requestAnimationFrame(loop);
      return () => {
        cancelAnimationFrame(raf);
        audio.pause();
      };
    }

    let last = performance.now();
    const loop = (now: number) => {
      const dt = (now - last) * speed;
      last = now;
      let nt = timeRef.current + dt;
      if (nt >= totalMs) {
        nt = totalMs;
        setPlaying(false);
      }
      timeRef.current = nt;
      setTimeMs(nt);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [playing, speed, totalMs, audioUrl]);

  const togglePlay = () => {
    if (!lines.length && !audioUrl) return;
    if (timeRef.current >= totalMs - 10) seek(0);
    setPlaying((p) => !p);
  };

  return (
    <div className="min-h-screen font-body text-ink">
      {/* ---------------- header ---------------- */}
      <header className="sticky top-0 z-40 border-b border-stage-600 bg-stage-950/85 backdrop-blur">
        <div className="mx-auto flex max-w-[1440px] items-center gap-4 px-4 py-3 md:px-6">
          <Logo />
          <div>
            <h1 className="marquee-title font-display text-xl leading-none tracking-wide text-ink">
              SYLLA<span className="text-coral">BOX</span>
            </h1>
            <p className="mt-1 font-mono text-[9.5px] tracking-[0.24em] text-mut">
              SRT · LRC → CLONE HERO LYRIC EVENTS
            </p>
          </div>

          <div className="ml-auto hidden items-center gap-3 lg:flex">
            {["SUBTITLES", "SYLLABLES", "[Events]"].map((step, i) => (
              <span key={step} className="flex items-center gap-3">
                {i > 0 && (
                  <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 text-teal" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M4 12h15m0 0l-6-6m6 6l-6 6" />
                  </svg>
                )}
                <span className="rounded border border-stage-600 bg-stage-800 px-2.5 py-1 font-mono text-[10px] tracking-[0.18em] text-ink-dim">
                  {step}
                </span>
              </span>
            ))}
            <span className="mx-1 h-6 w-px bg-stage-600" />
            <span className="eq" aria-hidden><i /><i /><i /><i /><i /></span>
          </div>
        </div>

        <div className="ticker-wrap" aria-hidden>
          <div className="ticker">
            {[0, 1].map((half) => (
              <div key={half} className="flex flex-none items-center">
                {TICKER.map((t) => (
                  <span key={`${half}-${t}`} className="flex items-center whitespace-nowrap font-mono text-[10px] tracking-[0.2em] text-mut">
                    <span className="px-4 text-coral">▪</span>
                    {t}
                  </span>
                ))}
              </div>
            ))}
          </div>
        </div>
      </header>

      {/* ---------------- main ---------------- */}
      <main className="mx-auto max-w-[1440px] space-y-6 px-4 py-6 md:px-6">
        <Reveal>
          <SyncConsole
            settings={settings}
            onChange={handleSettingsChange}
            notice={importNotice}
            onDismissNotice={() => setImportNotice(null)}
          />
        </Reveal>

        {lines.length > 0 && chart && (
          <Reveal>
            <div className="panel grid grid-cols-2 divide-x divide-stage-600 sm:grid-cols-5">
              {[
                ["CUES", String(loaded?.count ?? 0)],
                ["WORDS", stats.words.toLocaleString("en-US")],
                ["SYLLABLES", stats.syls.toLocaleString("en-US")],
                ["CHART EVENTS", chart.events.length.toLocaleString("en-US")],
                ["SPAN", fmtClock(lines[lines.length - 1].endMs)],
              ].map(([label, val]) => (
                <div key={label} className="px-3 py-3 text-center">
                  <p className="stat-num">{val}</p>
                  <p className="mt-1 font-mono text-[8.5px] tracking-[0.2em] text-mut">{label}</p>
                </div>
              ))}
            </div>
          </Reveal>
        )}

        <div className="grid gap-6 lg:grid-cols-12">
          <div className="min-w-0 space-y-6 lg:col-span-5">
            <Reveal>
              <InputPanel
                loaded={loaded}
                error={error}
                onParsed={handleParsed}
                onError={setError}
                onClear={handleClear}
              />
            </Reveal>
            <Reveal delay={90}>
              <CueSheet lines={rawLines} timeMs={timeMs} onSeek={(ms) => { seek(ms); }} />
            </Reveal>
          </div>
          <div className="min-w-0 lg:col-span-7">
            <Reveal delay={140} className="h-full">
              <SyllableEditor
                lines={lines}
                timeMs={timeMs}
                settings={settings}
                onOverride={(id, text) =>
                  setOverrides((prev) => {
                    const m = new Map(prev);
                    m.set(id, text);
                    return m;
                  })
                }
                onRestore={(id) =>
                  setOverrides((prev) => {
                    const m = new Map(prev);
                    m.delete(id);
                    return m;
                  })
                }
                onRemove={(id) =>
                  setRemoved((prev) => {
                    const s = new Set(prev);
                    s.add(id);
                    return s;
                  })
                }
              />
            </Reveal>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-12">
          <div className="min-w-0 lg:col-span-7">
            <Reveal>
              <PreviewStage
                lines={lines}
                timeMs={timeMs}
                totalMs={totalMs}
                playing={playing}
                speed={speed}
                settings={settings}
                audioUrl={audioUrl}
                audioName={audioName}
                audioDurMs={audioDurMs}
                volume={volume}
                onLoadAudio={loadAudioFile}
                onRemoveAudio={removeAudio}
                onVolume={setVolume}
                onTogglePlay={togglePlay}
                onRestart={() => seek(0)}
                onSeek={seek}
                onCycleSpeed={() => setSpeed((s) => (s === 1 ? 0.75 : s === 0.75 ? 0.5 : 1))}
              />
            </Reveal>
          </div>
          <div className="min-w-0 lg:col-span-5">
            <Reveal delay={90}>
              <OutputConsole
                chart={chart}
                lines={lines}
                meta={meta}
                imported={imported}
                importError={importError}
                onImportFile={importChartFile}
              />
            </Reveal>
          </div>
        </div>

        <Reveal>
          <Reference />
        </Reveal>
      </main>

      {/* ---------------- footer ---------------- */}
      <footer className="border-t border-stage-600 bg-stage-950/70">
        <div className="mx-auto flex max-w-[1440px] flex-col items-center gap-2 px-4 py-6 text-center md:flex-row md:justify-between md:text-left">
          <p className="font-mono text-[10px] tracking-[0.18em] text-mut">
            SYLLABOX — RUNS ENTIRELY IN YOUR BROWSER · NO FILES LEAVE YOUR MACHINE
          </p>
          <p className="font-mono text-[10px] tracking-[0.18em] text-stage-500">
            PREVIEW EVERY CHART IN CLONE HERO BEFORE SHIPPING ▸ KEEP ON ROCKING
          </p>
        </div>
      </footer>
    </div>
  );
}
