import type { CSSProperties } from "react";
import type { Settings } from "../lib/types";
import { tickToMs } from "../lib/chart";
import { clamp, fmtTime } from "../lib/format";

interface Props {
  settings: Settings;
  onChange: (patch: Partial<Settings>) => void;
  notice: string | null;
  onDismissNotice: () => void;
}

function Toggle({
  label,
  hint,
  checked,
  onChange,
}: {
  label: string;
  hint: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-stage-700 py-2.5 last:border-0">
      <div>
        <p className="text-[13px] font-semibold text-ink">{label}</p>
        <p className="font-mono text-[10px] leading-relaxed text-mut">{hint}</p>
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        className="switch"
        onClick={() => onChange(!checked)}
      />
    </div>
  );
}

export function SyncConsole({ settings, onChange, notice, onDismissNotice }: Props) {
  const num = (v: string) => {
    const n = parseInt(v, 10);
    return Number.isNaN(n) ? 0 : n;
  };
  const numF = (v: string) => {
    const n = parseFloat(v);
    return Number.isNaN(n) ? 0 : n;
  };

  const tMap = settings.tempoMap && settings.tempoMap.length > 1 ? settings.tempoMap : null;
  const anchorCount = settings.anchors?.length ?? 0;
  const resOptions = Array.from(new Set([96, 192, 384, settings.resolution])).sort((a, b) => a - b);
  const resLabel = (r: number) =>
    r === 96 ? "96 — coarse" : r === 192 ? "192 — Clone Hero standard" : r === 384 ? "384 — extra fine" : `${r} — from imported chart`;

  return (
    <section className="panel">
      <div className="panel-head">
        <span className="kicker">02 · Sync console</span>
        <h2 className="font-display text-sm tracking-wide text-ink">TIMING → TICKS</h2>
        <div className="ml-auto flex items-center gap-2">
          <span className="font-mono text-[10px] tracking-widest text-mut">BEAT</span>
          <span
            className="lamp"
            style={{ "--beat": `${clamp(60 / settings.bpm, 0.12, 2)}s` } as CSSProperties}
          />
          <span className="font-mono text-[11px] font-bold text-amber">{settings.bpm} BPM</span>
        </div>
      </div>

      {notice && (
        <div className="notice flex items-start gap-2.5 border-b border-teal/40 bg-teal/10 px-4 py-2.5">
          <svg viewBox="0 0 24 24" className="mt-px h-3.5 w-3.5 flex-none text-teal" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 3v12m0 0l-4-4m4 4l4-4" />
            <path d="M4 19h16" />
          </svg>
          <p className="flex-1 font-mono text-[10.5px] leading-relaxed text-teal">{notice}</p>
          <button
            className="font-mono text-[11px] text-mut transition-colors hover:text-ink"
            onClick={onDismissNotice}
            aria-label="Dismiss notice"
          >
            ✕
          </button>
        </div>
      )}

      {(tMap || anchorCount > 0) && (
        <div className="notice flex flex-wrap items-center gap-x-3 gap-y-2 border-b border-amber/40 bg-amber/[0.07] px-4 py-2.5">
          {tMap && (
            <span className="rounded border border-amber/60 bg-amber/15 px-1.5 py-0.5 font-mono text-[9px] font-bold tracking-[0.18em] text-amber">
              TEMPO MAP · {tMap.length} MARKERS
            </span>
          )}
          {anchorCount > 0 && (
            <span className="rounded border border-teal/60 bg-teal/10 px-1.5 py-0.5 font-mono text-[9px] font-bold tracking-[0.18em] text-teal">
              {anchorCount} ANCHOR{anchorCount > 1 ? "S" : ""}
            </span>
          )}
          {tMap && (
            <span className="flex flex-wrap items-center gap-x-2.5 gap-y-1 font-mono text-[10px] text-ink-dim">
              {tMap.slice(0, 6).map((t, i) => (
                <span key={`${t.tick}-${i}`} className="whitespace-nowrap">
                  <span className="font-bold text-amber">{t.bpm}</span>
                  <span className="text-mut"> @tick {t.tick.toLocaleString("en-US")}</span>
                  <span className="text-stage-500"> ({fmtTime(tickToMs(t.tick, settings))})</span>
                </span>
              ))}
              {tMap.length > 6 && <span className="text-mut">+{tMap.length - 6} more</span>}
            </span>
          )}
          {anchorCount > 0 && !tMap && (
            <span className="font-mono text-[10px] text-ink-dim">absolute sync pins from the imported chart</span>
          )}
          <button
            className="btn ml-auto !px-2 !py-1 text-[10px]"
            onClick={() => onChange({ tempoMap: null, anchors: null })}
            title="Discard the tempo map and anchors, use one constant BPM"
          >
            Use constant {settings.bpm} BPM
          </button>
        </div>
      )}

      <div className="grid gap-x-6 gap-y-4 p-4 md:grid-cols-2 xl:grid-cols-[1.25fr_1.25fr_1fr]">
        {/* left: offset + bpm */}
        <div className="space-y-4">
          <div>
            <label className="field-label" htmlFor="offset">Audio offset (ms)</label>
            <div className="flex gap-1.5">
              <input
                id="offset"
                type="number"
                className="input"
                value={settings.offsetMs}
                onChange={(e) => onChange({ offsetMs: num(e.target.value) })}
              />
            </div>
            <div className="mt-1.5 flex gap-1.5">
              {[-100, -10, 10, 100].map((d) => (
                <button
                  key={d}
                  className="btn flex-1 !px-0 !py-1 font-mono text-[10px]"
                  onClick={() => onChange({ offsetMs: settings.offsetMs + d })}
                >
                  {d > 0 ? `+${d}` : d}
                </button>
              ))}
            </div>
            <p className="mt-1.5 font-mono text-[10px] leading-relaxed text-mut">
              subtitle time that lands on tick 0
            </p>
          </div>

          <div>
            <label className="field-label" htmlFor="bpm">
              {settings.tempoMap && settings.tempoMap.length > 1 ? "First tempo (BPM) — map active" : "Song tempo (BPM)"}
            </label>
            <input
              id="bpm"
              type="number"
              min={30}
              max={400}
              step={0.01}
              className="input"
              value={settings.bpm}
              onChange={(e) => onChange({ bpm: clamp(numF(e.target.value), 30, 400) })}
            />
            {settings.tempoMap && settings.tempoMap.length > 1 && (
              <p className="mt-1.5 font-mono text-[10px] leading-relaxed text-amber/90">
                metronome only — tick math follows the full tempo map; editing this clears it
              </p>
            )}
          </div>
        </div>

        {/* middle: resolution / hold / split */}
        <div className="space-y-4">
          <div>
            <label className="field-label" htmlFor="res">Resolution (ticks / beat)</label>
            <select
              id="res"
              className="input"
              value={settings.resolution}
              onChange={(e) => onChange({ resolution: parseInt(e.target.value, 10) })}
            >
              {resOptions.map((r) => (
                <option key={r} value={r}>
                  {resLabel(r)}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="field-label" htmlFor="hold">Line hold (ms)</label>
            <input
              id="hold"
              type="number"
              min={500}
              max={15000}
              step={100}
              className="input"
              value={settings.holdMs}
              onChange={(e) => onChange({ holdMs: clamp(num(e.target.value), 500, 15000) })}
            />
            <p className="mt-1.5 font-mono text-[10px] leading-relaxed text-mut">
              max line length when the format has no end times (LRC)
            </p>
          </div>
          <div>
            <label className="field-label" htmlFor="dist">Syllable weight</label>
            <select
              id="dist"
              className="input"
              value={settings.distMode}
              onChange={(e) => onChange({ distMode: e.target.value as Settings["distMode"] })}
            >
              <option value="chars">by letter count</option>
              <option value="equal">equal shares</option>
            </select>
          </div>
        </div>

        {/* right: toggles */}
        <div className="md:col-span-2 xl:col-span-1">
          <Toggle
            label='Hyphen continuations “-”'
            hint="later syllables join onto the previous one, rebuilding each word"
            checked={settings.hyphenCont}
            onChange={(v) => onChange({ hyphenCont: v })}
          />
          <Toggle
            label='Line-end hold “+”'
            hint="last syllable of a line lingers until the next event"
            checked={settings.holdPlus}
            onChange={(v) => onChange({ holdPlus: v })}
          />
          <div className="flex items-start justify-between gap-3 py-2.5">
            <div className="flex-1">
              <p className="text-[13px] font-semibold text-ink">Section markers</p>
              <p className="font-mono text-[10px] leading-relaxed text-mut">
                E "section" events for the practice menu
              </p>
            </div>
            {settings.sections && (
              <select
                aria-label="Section interval"
                className="input !w-24 !py-1 text-[11px]"
                value={settings.sectionEvery}
                onChange={(e) => onChange({ sectionEvery: parseInt(e.target.value, 10) })}
              >
                {[2, 3, 4, 6, 8].map((n) => (
                  <option key={n} value={n}>every {n}</option>
                ))}
              </select>
            )}
            <button
              type="button"
              role="switch"
              aria-checked={settings.sections}
              aria-label="Section markers"
              className="switch"
              onClick={() => onChange({ sections: !settings.sections })}
            />
          </div>
        </div>
      </div>
    </section>
  );
}
