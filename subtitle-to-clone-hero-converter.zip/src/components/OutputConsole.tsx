import { useEffect, useRef, useState } from "react";
import type { ChartResult, LyricLine, SongMeta } from "../lib/types";
import type { ImportedChart } from "../lib/chartImport";
import { fmtClock } from "../lib/format";
import { cn } from "../utils/cn";

interface Props {
  chart: ChartResult | null;
  lines: LyricLine[];
  meta: SongMeta;
  imported: ImportedChart | null;
  importError: string | null;
  onImportFile: (file: File) => void;
}

const ROW_RE = /^(\s*)(\d+)( = E )("(?:section|lyric)")(.*)$/;
const MAX_ROWS = 400;

function renderRow(row: string, i: number) {
  const m = row.match(ROW_RE);
  if (!m) {
    return (
      <div key={i} className={cn("whitespace-pre", (row.startsWith("[") || row === "{" || row === "}") && "text-teal")}>
        {row}
      </div>
    );
  }
  return (
    <div key={i} className="whitespace-pre">
      <span>{m[1]}</span>
      <span className="text-gold">{m[2]}</span>
      <span className="text-mut">{m[3]}</span>
      <span className={m[4].includes("section") ? "font-bold text-coral" : "font-bold text-amber"}>{m[4]}</span>
      <span className="text-ink">{m[5]}</span>
    </div>
  );
}

const esc = (s: string) => s.replace(/\\/g, "\\\\").replace(/"/g, '\\"');

function MetaCell({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="rounded-md border border-stage-700 bg-stage-950/60 px-2.5 py-2">
      <p className="font-mono text-[8.5px] tracking-[0.2em] text-mut">{label}</p>
      <p className={cn("mt-0.5 truncate font-mono text-[12px] font-bold", accent ? "text-teal" : "text-ink")} title={value}>
        {value}
      </p>
    </div>
  );
}

export function OutputConsole({ chart, lines, meta, imported, importError, onImportFile }: Props) {
  const [tab, setTab] = useState<"snippet" | "full" | "imported">("full");
  const [copied, setCopied] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const hasChart = !!chart && lines.length > 0;

  // jump to the imported view whenever a .chart lands
  useEffect(() => {
    if (imported) setTab("imported");
  }, [imported]);

  let activeTab: "full" | "snippet" | "imported" | null = tab;
  if (tab === "imported" && !imported) activeTab = hasChart ? "full" : null;
  if ((tab === "full" || tab === "snippet") && !hasChart) activeTab = imported ? "imported" : null;

  const text =
    chart && activeTab === "full"
      ? chart.full
      : chart && activeTab === "snippet"
        ? chart.snippet
        : "";
  const rows = text.split("\n");
  const shown = rows.slice(0, MAX_ROWS);

  const importedRows = imported
    ? imported.events.map((e) => `  ${e.tick} = E "${esc(e.type)}" "${esc(e.payload)}"`)
    : [];

  const copy = async () => {
    const payload = activeTab === "imported" ? `[Events]\n{\n${importedRows.join("\n")}\n}` : text;
    try {
      await navigator.clipboard.writeText(payload);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = payload;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  const download = () => {
    const base = (meta.title || imported?.name || "lyrics").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "lyrics";
    const fname = activeTab === "full" ? `${base}.chart` : activeTab === "snippet" ? `${base}-events.txt` : `${base}-imported-events.txt`;
    const payload = activeTab === "imported" ? `[Events]\n{\n${importedRows.join("\n")}\n}` : text;
    const blob = new Blob([payload], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = fname;
    a.click();
    URL.revokeObjectURL(url);
  };

  const lyricGen = chart ? chart.events.filter((e) => e.kind === "lyric").length : 0;
  const sectionGen = chart ? chart.events.filter((e) => e.kind === "section").length : 0;

  const tabs: { id: "full" | "snippet" | "imported"; label: string; show: boolean }[] = [
    { id: "full", label: "FULL .CHART", show: hasChart },
    { id: "snippet", label: "[Events] ONLY", show: hasChart },
    { id: "imported", label: "IMPORTED", show: !!imported },
  ];

  return (
    <section
      className={cn("panel relative flex flex-col transition-shadow", dragOver && "drop-glow")}
      onDragOver={(e) => {
        if (e.dataTransfer.types.includes("Files")) {
          e.preventDefault();
          setDragOver(true);
        }
      }}
      onDragLeave={() => setDragOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragOver(false);
        const f = Array.from(e.dataTransfer.files).find((f) => /\.chart$/i.test(f.name));
        if (f) onImportFile(f);
      }}
    >
      <div className="panel-head">
        <span className="kicker">06 · Output</span>
        <h2 className="font-display text-sm tracking-wide text-ink">CHART EVENTS</h2>
        <span className="blink-caret ml-2 inline-block h-3 w-1.5 bg-teal/70" aria-hidden />
        <button className="btn btn-teal ml-auto !px-2.5 !py-1 text-[10px]" onClick={() => fileRef.current?.click()}>
          <svg viewBox="0 0 24 24" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 15V3m0 0L7 8m5-5l5 5" />
            <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
          </svg>
          LOAD .CHART
        </button>
        <input
          ref={fileRef}
          type="file"
          accept=".chart"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onImportFile(f);
            e.target.value = "";
          }}
        />
      </div>

      {dragOver && (
        <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center rounded-[10px] bg-stage-950/80">
          <p className="font-mono text-[12px] font-bold tracking-[0.3em] text-teal">DROP .CHART TO IMPORT</p>
        </div>
      )}

      {importError && (
        <div className="border-b border-stage-600 bg-danger/10 px-4 py-2 font-mono text-[10px] leading-relaxed text-danger">
          <span className="font-bold">IMPORT ERROR — </span>
          {importError}
        </div>
      )}

      {!hasChart && !imported ? (
        <div className="flex flex-1 flex-col items-center justify-center px-6 py-14 text-center">
          <p className="font-mono text-[11px] leading-relaxed text-mut">
            <span className="text-teal">[Events]</span> output appears here the moment lyrics are parsed —
            <br />
            or <span className="text-teal">load an existing .chart</span> to match its settings and browse its events.
          </p>
        </div>
      ) : (
        <>
          {/* stats strip */}
          {activeTab !== "imported" && chart && (
            <div className="grid grid-cols-4 divide-x divide-stage-600 border-b border-stage-600">
              {[
                ["LYRIC EVTS", lyricGen],
                ["SECTIONS", sectionGen],
                ["FIRST TICK", chart.firstTick.toLocaleString("en-US")],
                ["LAST TICK", chart.lastTick.toLocaleString("en-US")],
              ].map(([label, val]) => (
                <div key={label as string} className="px-3 py-2.5 text-center">
                  <p className="stat-num">{val}</p>
                  <p className="mt-1 font-mono text-[8.5px] tracking-[0.18em] text-mut">{label}</p>
                </div>
              ))}
            </div>
          )}

          {activeTab === "imported" && imported && (
            <div className="border-b border-stage-600 bg-teal/[0.04] p-3">
              <div className="mb-2 flex flex-wrap items-center gap-2">
                <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 text-teal" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M14 3v5h5M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8l-5-5z" />
                </svg>
                <span className="max-w-[200px] truncate font-mono text-[11px] font-bold text-teal" title={imported.fileName}>
                  {imported.fileName}
                </span>
                <span className="font-mono text-[10px] text-mut">
                  {imported.events.length.toLocaleString("en-US")} events
                </span>
                {hasChart && (
                  <span className="ml-auto font-mono text-[9.5px] tracking-wide text-mut">
                    GENERATED {lyricGen} VS IMPORTED {imported.lyricCount} LYRIC EVTS
                  </span>
                )}
              </div>
              <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-4">
                <MetaCell label="SONG" value={imported.name ?? "—"} />
                <MetaCell label="ARTIST" value={imported.artist ?? "—"} />
                <MetaCell label="CHARTER" value={imported.charter ?? "—"} />
                <MetaCell label="RESOLUTION" value={String(imported.resolution)} accent />
                <MetaCell
                  label="TEMPO"
                  value={
                    imported.tempos.length
                      ? `${imported.tempos[0].bpm} BPM${imported.tempos.length > 1 ? ` (+${imported.tempos.length - 1} changes)` : ""}`
                      : "—"
                  }
                  accent
                />
                <MetaCell label="DELAY" value={`${imported.delaySec}s`} accent />
                <MetaCell label="LENGTH" value={imported.songLengthMs ? fmtClock(imported.songLengthMs) : "—"} />
                <MetaCell label="PREVIEW" value={imported.previewStartMs ? fmtClock(imported.previewStartMs) : "0:00"} />
              </div>
              {imported.anchors.length > 0 && (
                <p className="mt-2 font-mono text-[9.5px] tracking-wide text-teal">
                  ▸ {imported.anchors.length} anchor (A) marker{imported.anchors.length > 1 ? "s" : ""} imported — tick conversion pins to them
                </p>
              )}
              {imported.noteCounts.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {imported.noteCounts.map((n) => (
                    <span key={n.section} className="rounded border border-stage-600 bg-stage-800 px-1.5 py-0.5 font-mono text-[9px] tracking-wide text-ink-dim">
                      <span className="text-coral">{n.section.replace(/(Single|Double[A-Za-z]*|Drums[A-Za-z]*|GHL[A-Za-z]*)/, " $1").toUpperCase()}</span>
                      {" · "}{n.notes.toLocaleString("en-US")} notes
                    </span>
                  ))}
                </div>
              )}
              {imported.warnings.map((w, i) => (
                <p key={i} className="mt-1.5 font-mono text-[9.5px] leading-relaxed text-amber">▸ {w}</p>
              ))}
            </div>
          )}

          {chart && chart.warnings.length > 0 && activeTab !== "imported" && (
            <div className="space-y-1 border-b border-stage-600 bg-amber/5 px-4 py-2.5">
              {chart.warnings.map((w, i) => (
                <p key={i} className="flex items-start gap-2 font-mono text-[10px] leading-relaxed text-amber">
                  <svg viewBox="0 0 24 24" className="mt-px h-3 w-3 flex-none" fill="currentColor">
                    <path d="M12 2L1 21h22L12 2zm1 14h-2v2h2v-2zm0-7h-2v5h2V9z" />
                  </svg>
                  {w}
                </p>
              ))}
            </div>
          )}

          {/* tabs */}
          <div className="flex items-center gap-1 border-b border-stage-600 px-3 pt-2">
            {tabs.filter((t) => t.show).map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={cn(
                  "border-b-2 px-3 pb-2 font-mono text-[10px] tracking-[0.18em] transition-colors",
                  activeTab === t.id ? "border-coral text-coral" : "border-transparent text-mut hover:text-ink",
                  t.id === "imported" && activeTab === t.id && "border-teal text-teal",
                )}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* content */}
          {activeTab === "imported" && imported ? (
            importedRows.length ? (
              <pre className="max-h-[330px] flex-1 overflow-auto bg-stage-950/80 p-3 font-mono text-[11px] leading-[1.55]">
                <div className="text-teal">[Events] — {imported.events.length.toLocaleString("en-US")} from {imported.fileName}</div>
                {importedRows.slice(0, MAX_ROWS).map(renderRow)}
                {importedRows.length > MAX_ROWS && (
                  <div className="text-mut">… +{(importedRows.length - MAX_ROWS).toLocaleString("en-US")} more rows</div>
                )}
              </pre>
            ) : (
              <div className="px-5 py-10 text-center font-mono text-[11px] leading-relaxed text-mut">
                no [Events] in this chart yet — generate lyrics and merge them in
              </div>
            )
          ) : (
            <pre className="max-h-[330px] flex-1 overflow-auto bg-stage-950/80 p-3 font-mono text-[11px] leading-[1.55]">
              {shown.map(renderRow)}
              {rows.length > MAX_ROWS && (
                <div className="text-mut">… +{(rows.length - MAX_ROWS).toLocaleString("en-US")} more rows</div>
              )}
            </pre>
          )}

          <div className="flex flex-wrap gap-2 border-t border-stage-600 p-3">
            <button className="btn btn-amber" onClick={copy}>
              {copied ? (
                <>
                  <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round"><path d="M4 12l5 5L20 6" /></svg>
                  Copied!
                </>
              ) : (
                <>
                  <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="9" y="9" width="11" height="11" rx="2" /><path d="M5 15V5a2 2 0 0 1 2-2h10" /></svg>
                  Copy {activeTab === "full" ? ".chart" : "events"}
                </>
              )}
            </button>
            <button className="btn btn-teal" onClick={download}>
              <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3v12m0 0l-4-4m4 4l4-4" /><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" /></svg>
              Download
            </button>
            <p className="w-full font-mono text-[10px] leading-relaxed text-mut">
              {activeTab === "imported"
                ? "sync console matched to this chart — generate lyric events against it, then merge the new [Events] in your chart editor."
                : "open the .chart in Clone Hero / Moonscraper, or merge the [Events] block into an existing chart file."}
            </p>
          </div>
        </>
      )}
    </section>
  );
}
