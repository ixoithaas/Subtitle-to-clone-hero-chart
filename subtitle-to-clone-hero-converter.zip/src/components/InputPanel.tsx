import { useRef, useState } from "react";
import { parseSubtitleFile, type ParseResult } from "../lib/parsers";
import { DEMO_LRC, DEMO_SRT } from "../lib/demo";
import { cn } from "../utils/cn";

export interface LoadedInfo {
  format: "srt" | "lrc";
  count: number;
  sourceName: string;
  meta: { artist?: string; title?: string };
  notes: string[];
}

interface Props {
  loaded: LoadedInfo | null;
  error: string | null;
  onParsed: (res: ParseResult, sourceName: string) => void;
  onError: (msg: string | null) => void;
  onClear: () => void;
}

export function InputPanel({ loaded, error, onParsed, onError, onClear }: Props) {
  const [active, setActive] = useState(false);
  const [pasted, setPasted] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const handleText = (text: string, name: string) => {
    if (!text.trim()) {
      onError("That input is empty.");
      return;
    }
    try {
      const res = parseSubtitleFile(text, name);
      onError(null);
      onParsed(res, name);
    } catch (e) {
      onError((e as Error).message);
    }
  };

  const readFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => handleText(String(reader.result ?? ""), file.name);
    reader.onerror = () => onError("Could not read that file.");
    reader.readAsText(file);
  };

  return (
    <section className="panel">
      <div className="panel-head">
        <span className="kicker">01 · Source</span>
        <h2 className="font-display text-sm tracking-wide text-ink">FEED THE LYRICS</h2>
        <span className="ml-auto font-mono text-[10px] tracking-widest text-mut">.SRT / .LRC</span>
      </div>

      <div className="space-y-4 p-4">
        <div
          className={cn("dropzone px-5 py-7 text-center", active && "active")}
          onDragOver={(e) => {
            e.preventDefault();
            setActive(true);
          }}
          onDragLeave={() => setActive(false)}
          onDrop={(e) => {
            e.preventDefault();
            setActive(false);
            const f = e.dataTransfer.files?.[0];
            if (f) readFile(f);
          }}
        >
          <svg viewBox="0 0 24 24" className="mx-auto mb-2 h-8 w-8 text-teal" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 3v12" />
            <path d="M7 8l5-5 5 5" />
            <path d="M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3" />
          </svg>
          <p className="text-sm font-semibold text-ink">
            Drop a subtitle file here
          </p>
          <p className="mt-1 font-mono text-[11px] text-mut">or</p>
          <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
            <button className="btn btn-teal" onClick={() => fileRef.current?.click()}>
              Browse files
            </button>
            <button className="btn" onClick={() => handleText(DEMO_LRC, "neon-meridian-demo.lrc")}>
              Demo .lrc
            </button>
            <button className="btn" onClick={() => handleText(DEMO_SRT, "neon-meridian-demo.srt")}>
              Demo .srt
            </button>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept=".srt,.lrc,.txt"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) readFile(f);
              e.target.value = "";
            }}
          />
        </div>

        <div>
          <label className="field-label" htmlFor="paste-area">or paste raw subtitle text</label>
          <textarea
            id="paste-area"
            className="input h-24 resize-y text-[11px] leading-relaxed"
            placeholder={"1\n00:00:08,000 --> 00:00:11,500\nStreetlights flicker on the interstate\n\n…or [00:08.00]Streetlights flicker"}
            value={pasted}
            onChange={(e) => setPasted(e.target.value)}
          />
          <button
            className="btn btn-coral mt-2 w-full"
            disabled={!pasted.trim()}
            onClick={() => handleText(pasted, "pasted-subtitles")}
          >
            Parse pasted text
          </button>
        </div>

        {error && (
          <div className="rounded-md border border-danger/60 bg-danger/10 px-3 py-2 font-mono text-[11px] leading-relaxed text-danger">
            <span className="font-bold">PARSE ERROR — </span>
            {error}
          </div>
        )}

        {loaded && (
          <div className="rounded-md border border-stage-600 bg-stage-950/60 p-3">
            <div className="flex flex-wrap items-center gap-2">
              <span
                className={cn(
                  "rounded px-2 py-0.5 font-mono text-[10px] font-bold tracking-widest",
                  loaded.format === "srt"
                    ? "bg-coral/15 text-coral border border-coral/50"
                    : "bg-teal/15 text-teal border border-teal/50",
                )}
              >
                {loaded.format.toUpperCase()}
              </span>
              <span className="max-w-[180px] truncate font-mono text-[11px] text-ink">{loaded.sourceName}</span>
              <span className="font-mono text-[11px] text-mut">{loaded.count} cues</span>
              <button className="btn ml-auto !px-2 !py-1 text-[11px]" onClick={onClear}>
                Clear
              </button>
            </div>
            {(loaded.meta.artist || loaded.meta.title) && (
              <p className="mt-2 text-xs text-ink-dim">
                <span className="font-semibold text-gold">{loaded.meta.title ?? "Untitled"}</span>
                {loaded.meta.artist && <span className="text-mut"> — {loaded.meta.artist}</span>}
              </p>
            )}
            {loaded.notes.map((n, i) => (
              <p key={i} className="mt-1.5 font-mono text-[10px] leading-relaxed text-teal/90">▸ {n}</p>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
