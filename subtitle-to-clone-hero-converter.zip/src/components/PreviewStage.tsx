import { useEffect, useRef, useState, type CSSProperties, type PointerEvent } from "react";
import type { LyricLine, Settings } from "../lib/types";
import { bpmAtMs, msToTick } from "../lib/chart";
import { clamp, fmtTime } from "../lib/format";
import { cn } from "../utils/cn";

interface Props {
  lines: LyricLine[];
  timeMs: number;
  totalMs: number;
  playing: boolean;
  speed: number;
  settings: Settings;
  audioUrl: string | null;
  audioName: string | null;
  audioDurMs: number;
  volume: number;
  onLoadAudio: (file: File) => void;
  onRemoveAudio: () => void;
  onVolume: (v: number) => void;
  onTogglePlay: () => void;
  onRestart: () => void;
  onSeek: (ms: number) => void;
  onCycleSpeed: () => void;
}

const WAVE_H = 64;

function Waveform({
  peaks,
  timeMs,
  totalMs,
  onSeek,
}: {
  peaks: number[];
  timeMs: number;
  totalMs: number;
  onSeek: (ms: number) => void;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const dragging = useRef(false);

  useEffect(() => {
    const cv = canvasRef.current;
    const wrap = wrapRef.current;
    if (!cv || !wrap) return;
    const draw = () => {
      const w = wrap.clientWidth;
      if (w === 0) return;
      const dpr = window.devicePixelRatio || 1;
      cv.width = w * dpr;
      cv.height = WAVE_H * dpr;
      cv.style.width = `${w}px`;
      cv.style.height = `${WAVE_H}px`;
      const g = cv.getContext("2d");
      if (!g) return;
      g.scale(dpr, dpr);
      g.clearRect(0, 0, w, WAVE_H);
      const n = peaks.length;
      const bw = w / n;
      const px = totalMs > 0 ? (timeMs / totalMs) * w : 0;
      for (let i = 0; i < n; i++) {
        const x = i * bw;
        const bh = Math.max(2, peaks[i] * (WAVE_H - 10));
        const y = (WAVE_H - bh) / 2;
        g.fillStyle = x <= px ? (i % 6 === 0 ? "#ff5d4d" : "#ffb454") : "#3b3252";
        g.fillRect(x, y, Math.max(1, bw - 1), bh);
      }
      g.save();
      g.fillStyle = "#ffd97a";
      g.shadowColor = "rgba(255, 180, 84, 0.85)";
      g.shadowBlur = 9;
      g.fillRect(px - 1, 2, 2, WAVE_H - 4);
      g.restore();
    };
    draw();
    const ro = new ResizeObserver(draw);
    ro.observe(wrap);
    return () => ro.disconnect();
  }, [peaks, timeMs, totalMs]);

  const seekFrom = (e: PointerEvent<HTMLDivElement>) => {
    const wrap = wrapRef.current;
    if (!wrap) return;
    const rect = wrap.getBoundingClientRect();
    const r = clamp((e.clientX - rect.left) / rect.width, 0, 1);
    onSeek(r * totalMs);
  };

  return (
    <div
      ref={wrapRef}
      className="group relative cursor-pointer touch-none select-none overflow-hidden rounded-md border border-stage-600 bg-stage-950/80"
      onPointerDown={(e) => {
        dragging.current = true;
        e.currentTarget.setPointerCapture(e.pointerId);
        seekFrom(e);
      }}
      onPointerMove={(e) => {
        if (dragging.current) seekFrom(e);
      }}
      onPointerUp={() => {
        dragging.current = false;
      }}
      onPointerCancel={() => {
        dragging.current = false;
      }}
      role="slider"
      aria-label="Seek within song waveform"
      aria-valuemin={0}
      aria-valuemax={Math.round(totalMs)}
      aria-valuenow={Math.round(timeMs)}
    >
      <canvas ref={canvasRef} className="block" />
      <span className="pointer-events-none absolute right-2 top-1 font-mono text-[8.5px] tracking-[0.2em] text-mut opacity-0 transition-opacity group-hover:opacity-100">
        CLICK / DRAG TO SEEK
      </span>
    </div>
  );
}

export function PreviewStage({
  lines,
  timeMs,
  totalMs,
  playing,
  speed,
  settings,
  audioUrl,
  audioName,
  audioDurMs,
  volume,
  onLoadAudio,
  onRemoveAudio,
  onVolume,
  onTogglePlay,
  onRestart,
  onSeek,
  onCycleSpeed,
}: Props) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [peaks, setPeaks] = useState<number[] | null>(null);
  const [decoding, setDecoding] = useState(false);

  // decode the song into waveform peaks (best-effort — preview works without)
  useEffect(() => {
    let cancelled = false;
    setPeaks(null);
    if (!audioUrl) return;
    setDecoding(true);
    (async () => {
      try {
        const buf = await fetch(audioUrl).then((r) => r.arrayBuffer());
        const Ctx =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const ctx = new Ctx();
        const decoded = await ctx.decodeAudioData(buf);
        const data = decoded.getChannelData(0);
        const N = 720;
        const step = Math.max(1, Math.floor(data.length / N));
        const out: number[] = [];
        for (let i = 0; i < N; i++) {
          let max = 0;
          const start = i * step;
          const end = Math.min(start + step, data.length);
          for (let j = start; j < end; j += 24) {
            const v = Math.abs(data[j]);
            if (v > max) max = v;
          }
          out.push(Math.pow(max, 0.6));
        }
        if (!cancelled) setPeaks(out);
        void ctx.close();
      } catch {
        /* no waveform — transport still works */
      } finally {
        if (!cancelled) setDecoding(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [audioUrl]);

  const cur = (() => {
    let found: LyricLine | undefined;
    for (const l of lines) if (timeMs >= l.startMs) found = l;
    return found;
  })();
  const showing = cur && timeMs <= cur.endMs + 400 ? cur : undefined;
  const nextLine = cur ? lines.find((l) => l.startMs > cur.startMs) : lines[0];

  let nowId: string | null = null;
  if (showing) {
    for (const w of showing.words) for (const s of w.syllables) if (s.startMs <= timeMs) nowId = s.id;
  }

  const fill = totalMs > 0 ? (timeMs / totalMs) * 100 : 0;

  return (
    <section className="panel flex flex-col">
      <div className="panel-head">
        <span className="kicker">05 · Stage preview</span>
        <h2 className="font-display text-sm tracking-wide text-ink">KARAOKE CHECK</h2>
        <div className="ml-auto flex items-center gap-2">
          <span
            className={cn(
              "rounded border px-1.5 py-px font-mono text-[8.5px] font-bold tracking-[0.16em]",
              audioUrl ? "border-teal/60 bg-teal/10 text-teal" : "border-stage-500 bg-stage-800 text-mut",
            )}
          >
            {audioUrl ? "AUDIO-DRIVEN" : "INTERNAL CLOCK"}
          </span>
          {settings.tempoMap && settings.tempoMap.length > 1 && (
            <span className="rounded border border-amber/60 bg-amber/10 px-1.5 py-px font-mono text-[8.5px] font-bold tracking-[0.16em] text-amber">
              TEMPO MAP
            </span>
          )}
          <span
            className="lamp"
            style={{ "--beat": `${Math.min(Math.max(60 / bpmAtMs(timeMs, settings), 0.12), 2)}s` } as CSSProperties}
          />
          <span className="hidden font-mono text-[10px] tabular-nums tracking-widest text-mut sm:inline">
            {Math.round(bpmAtMs(timeMs, settings) * 100) / 100} BPM
          </span>
        </div>
      </div>

      {/* audio source bar */}
      <div className="flex flex-wrap items-center gap-x-3 gap-y-2 border-b border-stage-600 bg-stage-950/60 px-4 py-2">
        {audioUrl ? (
          <>
            <svg viewBox="0 0 24 24" className="h-4 w-4 flex-none text-teal" fill="currentColor">
              <path d="M9 3v10.55A4 4 0 1 0 11 17V7h8V3H9z" />
            </svg>
            <span className="max-w-[220px] truncate font-mono text-[11px] text-ink" title={audioName ?? ""}>
              {audioName}
            </span>
            <span className="font-mono text-[10px] tabular-nums text-mut">
              {audioDurMs > 0 ? fmtTime(audioDurMs) : "…"}
            </span>
            <span className="ml-auto flex items-center gap-2">
              <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 text-mut" fill="currentColor">
                <path d="M3 10v4h4l5 5V5L7 10H3zm13.5 2a4.5 4.5 0 0 0-2.5-4v8a4.5 4.5 0 0 0 2.5-4z" />
              </svg>
              <input
                type="range"
                min={0}
                max={100}
                value={Math.round(volume * 100)}
                onChange={(e) => onVolume(parseInt(e.target.value, 10) / 100)}
                className="vol w-20 cursor-pointer"
                aria-label="Audio volume"
              />
              <button className="btn !px-2 !py-1 text-[10px]" onClick={() => fileRef.current?.click()}>
                Replace
              </button>
              <button
                className="btn !px-2 !py-1 text-[10px] hover:!border-danger hover:!text-danger"
                onClick={onRemoveAudio}
                title="Remove audio"
              >
                ✕
              </button>
            </span>
            {settings.offsetMs !== 0 && (
              <p className="w-full font-mono text-[9.5px] leading-relaxed text-amber/90">
                ⚠ chart offset only shifts ticks — here, subtitle 0:00 always meets audio 0:00.
              </p>
            )}
          </>
        ) : (
          <>
            <button className="btn btn-teal !px-2.5 !py-1 text-[10px]" onClick={() => fileRef.current?.click()}>
              <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <path d="M12 5v14M5 12h14" />
              </svg>
              Load audio
            </button>
            <span className="font-mono text-[10px] leading-relaxed text-mut">
              optional — play the real song to check sync · subtitle 0:00 = audio 0:00
            </span>
          </>
        )}
        <input
          ref={fileRef}
          type="file"
          accept="audio/*"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onLoadAudio(f);
            e.target.value = "";
          }}
        />
      </div>

      {/* stage */}
      <div className="relative flex min-h-[190px] flex-1 flex-col items-center justify-center overflow-hidden px-6 py-8">
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              "radial-gradient(420px 150px at 50% 118%, rgba(255,93,77,0.16), transparent 70%), radial-gradient(300px 120px at 50% -20%, rgba(57,208,195,0.10), transparent 70%)",
          }}
        />
        {showing ? (
          <>
            <p className="relative mb-3 font-mono text-[10px] tracking-[0.25em] text-mut">
              LINE {showing.index + 1} / {lines.length} · TICK {msToTick(timeMs, settings).toLocaleString("en-US")}
            </p>
            <p className="relative max-w-full text-center text-2xl font-bold leading-snug tracking-wide md:text-[28px]">
              {showing.words.map((w, wi) => (
                <span key={wi}>
                  {wi > 0 && " "}
                  {w.syllables.map((s) => (
                    <span
                      key={s.id}
                      className={cn(
                        "transition-colors duration-100",
                        nowId === s.id
                          ? "kara-now"
                          : nowId && s.startMs < timeMs
                            ? "kara-past"
                            : "kara-future",
                      )}
                    >
                      {s.text}
                    </span>
                  ))}
                </span>
              ))}
            </p>
          </>
        ) : lines.length === 0 ? (
          <p className="relative font-mono text-[11px] tracking-widest text-mut">
            THE STAGE IS DARK — LOAD SUBTITLES TO PREVIEW
          </p>
        ) : (
          <div className="relative text-center">
            <p className="text-3xl tracking-[0.5em] text-stage-500">· · ·</p>
            {nextLine && (
              <p className="mt-3 font-mono text-[10px] tracking-[0.25em] text-mut">
                NEXT LINE AT {fmtTime(nextLine.startMs)}
              </p>
            )}
          </div>
        )}
      </div>

      {/* transport */}
      <div className="border-t border-stage-600 p-4">
        {peaks ? (
          <Waveform peaks={peaks} timeMs={timeMs} totalMs={totalMs} onSeek={onSeek} />
        ) : (
          <input
            type="range"
            className="seek"
            min={0}
            max={Math.round(totalMs)}
            step={50}
            value={Math.round(timeMs)}
            style={{ "--fill": `${fill}%` } as CSSProperties}
            onChange={(e) => onSeek(parseInt(e.target.value, 10))}
            aria-label="Seek preview"
          />
        )}
        <div className="mt-3 flex items-center gap-3">
          <button className="btn !px-2.5 !py-2" onClick={onRestart} title="Back to start" aria-label="Restart">
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor">
              <path d="M6 5h2v14H6zM20 5v14L9.5 12z" />
            </svg>
          </button>
          <button
            className="flex h-11 w-11 items-center justify-center rounded-full border border-coral/70 bg-gradient-to-b from-coral to-[#d63c2f] text-stage-950 shadow-[0_6px_22px_-6px_rgba(255,93,77,0.8)] transition-transform hover:scale-105 active:scale-95"
            onClick={onTogglePlay}
            aria-label={playing ? "Pause" : "Play"}
          >
            {playing ? (
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="currentColor"><path d="M7 5h4v14H7zM13 5h4v14h-4z" /></svg>
            ) : (
              <svg viewBox="0 0 24 24" className="ml-0.5 h-5 w-5" fill="currentColor"><path d="M7 4l13 8-13 8z" /></svg>
            )}
          </button>
          <button className="btn !px-2.5 !py-2 font-mono text-[11px]" onClick={onCycleSpeed} title="Playback speed">
            {speed}×
          </button>
          {decoding && <span className="font-mono text-[9.5px] tracking-[0.2em] text-teal">DECODING WAVEFORM…</span>}
          <span className="ml-auto font-mono text-[12px] tabular-nums text-ink">
            <span className="text-amber">{fmtTime(timeMs)}</span>
            <span className="text-mut"> / {fmtTime(totalMs)}</span>
          </span>
        </div>
      </div>
    </section>
  );
}
