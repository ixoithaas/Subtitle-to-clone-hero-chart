import { useEffect, useRef } from "react";
import type { RawLine } from "../lib/types";
import { fmtTime } from "../lib/format";
import { cn } from "../utils/cn";

interface Props {
  lines: RawLine[] | null;
  timeMs: number;
  onSeek: (ms: number) => void;
}

export function CueSheet({ lines, timeMs, onSeek }: Props) {
  const rowRefs = useRef(new Map<number, HTMLButtonElement>());

  const activeIdx = (() => {
    if (!lines) return -1;
    let a = -1;
    for (let i = 0; i < lines.length; i++) if (timeMs >= lines[i].startMs) a = i;
    return a;
  })();

  useEffect(() => {
    if (activeIdx >= 0) {
      rowRefs.current.get(activeIdx)?.scrollIntoView({ block: "nearest", behavior: "smooth" });
    }
  }, [activeIdx]);

  return (
    <section className="panel">
      <div className="panel-head">
        <span className="kicker">03 · Cue sheet</span>
        <h2 className="font-display text-sm tracking-wide text-ink">SOURCE TIMELINE</h2>
        {lines && (
          <span className="ml-auto font-mono text-[10px] tracking-widest text-mut">
            {lines.length} cues · ends {fmtTime(lines[lines.length - 1].endMs ?? lines[lines.length - 1].startMs)}
          </span>
        )}
      </div>

      {!lines ? (
        <div className="px-5 py-10 text-center">
          <svg viewBox="0 0 24 24" className="mx-auto mb-2 h-7 w-7 text-stage-500" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
            <path d="M4 6h16M4 12h10M4 18h13" />
          </svg>
          <p className="font-mono text-[11px] text-mut">parsed cues will line up here — click one to jump the preview</p>
        </div>
      ) : (
        <div className="max-h-[380px] overflow-y-auto p-2">
          {lines.map((l, i) => (
            <button
              key={l.id}
              ref={(el) => {
                if (el) rowRefs.current.set(i, el);
                else rowRefs.current.delete(i);
              }}
              onClick={() => onSeek(l.startMs)}
              className={cn(
                "group flex w-full items-baseline gap-3 rounded-md border border-transparent px-3 py-2 text-left transition-colors",
                i === activeIdx
                  ? "border-amber/50 bg-amber/10"
                  : "hover:border-stage-500 hover:bg-stage-800",
              )}
            >
              <span className="w-6 flex-none text-right font-mono text-[10px] text-mut">{i + 1}</span>
              <span className={cn("flex-none font-mono text-[11px] tabular-nums", i === activeIdx ? "text-amber" : "text-teal")}>
                {fmtTime(l.startMs)}
              </span>
              {l.endMs !== null && (
                <span className="hidden flex-none font-mono text-[10px] tabular-nums text-stage-500 sm:inline">
                  → {fmtTime(l.endMs)}
                </span>
              )}
              <span className={cn("truncate text-[13px]", i === activeIdx ? "text-ink" : "text-ink-dim")}>
                {l.text}
              </span>
            </button>
          ))}
        </div>
      )}
    </section>
  );
}
