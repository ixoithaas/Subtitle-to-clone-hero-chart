import { useState } from "react";
import type { LyricLine, Settings } from "../lib/types";
import { lineToHyphenText } from "../lib/syllabify";
import { msToTick } from "../lib/chart";
import { fmtTime } from "../lib/format";
import { cn } from "../utils/cn";

interface Props {
  lines: LyricLine[];
  timeMs: number;
  settings: Settings;
  onOverride: (id: string, text: string) => void;
  onRestore: (id: string) => void;
  onRemove: (id: string) => void;
}

export function SyllableEditor({ lines, timeMs, settings, onOverride, onRestore, onRemove }: Props) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");

  const totalSyls = lines.reduce((a, l) => a + l.words.reduce((b, w) => b + w.syllables.length, 0), 0);

  const startEdit = (line: LyricLine) => {
    setDraft(lineToHyphenText(line));
    setEditingId(line.id);
  };

  return (
    <section className="panel flex min-h-full flex-col">
      <div className="panel-head">
        <span className="kicker">04 · Syllable grid</span>
        <h2 className="font-display text-sm tracking-wide text-ink">EVERY SYLLABLE, ON THE CLOCK</h2>
        <span className="ml-auto font-mono text-[10px] tracking-widest text-mut">
          {totalSyls.toLocaleString("en-US")} syllables
        </span>
      </div>

      {lines.length === 0 ? (
        <div className="flex flex-1 flex-col items-center justify-center px-6 py-14 text-center">
          <svg viewBox="0 0 48 48" className="mb-3 h-12 w-12 text-stage-500" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round">
            <rect x="4" y="10" width="12" height="28" rx="2" />
            <rect x="19" y="4" width="12" height="34" rx="2" />
            <rect x="34" y="16" width="10" height="22" rx="2" />
          </svg>
          <p className="text-sm font-semibold text-ink-dim">Nothing syllabified yet</p>
          <p className="mt-1 max-w-xs font-mono text-[11px] leading-relaxed text-mut">
            drop an .srt / .lrc file (or a demo) into the source panel — words get split into
            timed syllable chips right here.
          </p>
        </div>
      ) : (
        <div className="max-h-[640px] flex-1 space-y-2.5 overflow-y-auto p-3">
          {lines.map((line) => {
            const editing = editingId === line.id;
            const inRange = timeMs >= line.startMs && timeMs <= line.endMs + 250;
            let nowId: string | null = null;
            if (inRange) {
              for (const w of line.words) {
                for (const s of w.syllables) if (s.startMs <= timeMs) nowId = s.id;
              }
            }
            return (
              <div
                key={line.id}
                className={cn(
                  "rounded-lg border bg-stage-950/50 p-3 transition-colors",
                  inRange ? "border-amber/40" : "border-stage-700 hover:border-stage-500",
                )}
              >
                <div className="mb-2 flex flex-wrap items-center gap-x-3 gap-y-1">
                  <span className="font-mono text-[10px] text-mut">#{line.index + 1}</span>
                  <span className="font-mono text-[11px] font-bold tabular-nums text-amber">
                    {fmtTime(line.startMs)}
                  </span>
                  <span className="font-mono text-[10px] tabular-nums text-mut">
                    tick {msToTick(line.startMs, settings).toLocaleString("en-US")}
                  </span>
                  {line.custom && (
                    <span className="rounded border border-teal/50 bg-teal/10 px-1.5 py-px font-mono text-[9px] font-bold tracking-widest text-teal">
                      HAND-SPLIT
                    </span>
                  )}
                  <span className="ml-auto flex items-center gap-1.5">
                    {line.custom && (
                      <button className="btn !px-2 !py-1 text-[10px]" onClick={() => onRestore(line.id)}>
                        Reset
                      </button>
                    )}
                    <button
                      className="btn btn-teal !px-2 !py-1 text-[10px]"
                      onClick={() => (editing ? setEditingId(null) : startEdit(line))}
                    >
                      {editing ? "Close" : "Split"}
                    </button>
                    <button
                      className="btn !px-2 !py-1 text-[10px] hover:!border-danger hover:!text-danger"
                      title="Remove this line from the chart"
                      onClick={() => onRemove(line.id)}
                    >
                      ✕
                    </button>
                  </span>
                </div>

                {editing ? (
                  <div>
                    <input
                      className="input"
                      value={draft}
                      autoFocus
                      onChange={(e) => setDraft(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          onOverride(line.id, draft.trim());
                          setEditingId(null);
                        }
                        if (e.key === "Escape") setEditingId(null);
                      }}
                    />
                    <div className="mt-1.5 flex items-center justify-between gap-3">
                      <p className="font-mono text-[10px] text-mut">
                        hyphens mark syllable breaks — e.g. <span className="text-teal">ev-ry-bo-dy</span>
                      </p>
                      <span className="flex gap-1.5">
                        <button className="btn !py-1 text-[10px]" onClick={() => setEditingId(null)}>Cancel</button>
                        <button
                          className="btn btn-amber !py-1 text-[10px]"
                          onClick={() => {
                            onOverride(line.id, draft.trim());
                            setEditingId(null);
                          }}
                        >
                          Apply
                        </button>
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-1.5">
                    {line.words.map((w, wi) => (
                      <span key={wi} className="inline-flex gap-1.5">
                        {w.syllables.map((s, si) => (
                          <span
                            key={s.id}
                            className={cn(
                              "syl",
                              si === 0 && "word-start",
                              nowId === s.id ? "now" : nowId && s.startMs < timeMs ? "past" : "",
                            )}
                            style={{ animationDelay: `${Math.min(line.index * 30 + wi * 40 + si * 25, 600)}ms` }}
                            title={`${w.text} · ${fmtTime(s.startMs)} · tick ${msToTick(s.startMs, settings)}`}
                          >
                            <span className="word text-[13px] font-semibold leading-none text-ink">{s.text}</span>
                            <span className="t">{(s.startMs / 1000).toFixed(2)}s</span>
                          </span>
                        ))}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}
