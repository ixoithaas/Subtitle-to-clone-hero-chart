const SAMPLE: { pre: string; tick?: string; mid?: string; kind?: string; rest?: string }[] = [
  { pre: "[Events]", },
  { pre: "{" },
  { pre: "  ", tick: "15360", mid: ' = E ', kind: '"section"', rest: ' "Section 1"' },
  { pre: "  ", tick: "15360", mid: ' = E ', kind: '"lyric"', rest: ' "Street"' },
  { pre: "  ", tick: "15552", mid: ' = E ', kind: '"lyric"', rest: ' "-lights"' },
  { pre: "  ", tick: "15744", mid: ' = E ', kind: '"lyric"', rest: ' " flicker+"' },
  { pre: "}" },
];

const NOTES: [string, string][] = [
  ["Hyphens rebuild words", 'Clone Hero joins any lyric starting with "-" to the previous one: "Hel" + "-lo" reads as Hello. Syllabox emits this automatically.'],
  ["Plus holds the line", 'A trailing "+" keeps the last syllable on screen until the next event, so lyrics never blink out between lines.'],
  ["Sections feed the menu", 'E "section" events create named jump points in Clone Hero\'s practice menu — great for verse/chorus navigation.'],
  ["Ticks, not milliseconds", "Charts run on ticks: tick = round((ms − offset) × bpm ÷ 60000 × resolution). At 120 BPM / res 192, one beat = 500 ms = 192 ticks."],
  ["B, TS and A — the real SyncTrack", "Clone Hero & Moonscraper store tempo in B markers (BPM×1000: B 120000 = 120), time signatures in TS (TS 4000 = 4/4), and absolute sync points in A anchors (microseconds). Syllabox reads all three — and re-exports them. Docs calling TS “tempo” describe a convention these tools do not use."],
  ["Tempo maps & anchors are honored", "Import a chart with multiple B markers or anchors and every one is followed — tick conversion walks the map segment by segment, pinning to anchors, and generated charts re-export it all verbatim."],
  ["Enhanced LRC is gold", "Word-level tags like <00:12.34> inside .lrc lines are honored as syllable anchors — the tighter the tags, the tighter the chart."],
  ["Always eyeball the preview", "Auto-syllabification uses TeX en-US patterns; slang and stylized words may want a hand-split via the SPLIT button."],
];

export function Reference() {
  return (
    <section className="panel">
      <div className="panel-head">
        <span className="kicker">07 · Liner notes</span>
        <h2 className="font-display text-sm tracking-wide text-ink">HOW CLONE HERO READS LYRICS</h2>
      </div>
      <div className="grid gap-0 md:grid-cols-5">
        <div className="border-b border-stage-600 p-4 md:col-span-3 md:border-b-0 md:border-r">
          <p className="mb-3 font-mono text-[10px] tracking-[0.22em] text-mut">THE TARGET FORMAT</p>
          <pre className="overflow-x-auto rounded-md border border-stage-600 bg-stage-950/80 p-4 font-mono text-[11.5px] leading-[1.7]">
            {SAMPLE.map((r, i) => (
              <div key={i} className="whitespace-pre">
                {r.tick ? (
                  <>
                    <span>{r.pre}</span>
                    <span className="text-gold">{r.tick}</span>
                    <span className="text-mut">{r.mid}</span>
                    <span className={r.kind === '"section"' ? "font-bold text-coral" : "font-bold text-amber"}>{r.kind}</span>
                    <span className="text-ink">{r.rest}</span>
                  </>
                ) : (
                  <span className="text-teal">{r.pre}</span>
                )}
              </div>
            ))}
          </pre>
          <div className="mt-4 rounded-md border border-amber/30 bg-amber/5 px-4 py-3">
            <p className="font-mono text-[10px] tracking-[0.22em] text-amber">THE MATH</p>
            <p className="mt-1.5 font-mono text-[13px] text-ink">
              tick = round( (ms − offset) × bpm ÷ 60000 × resolution )
            </p>
          </div>
        </div>
        <div className="p-4 md:col-span-2">
          <p className="mb-3 font-mono text-[10px] tracking-[0.22em] text-mut">FIELD NOTES</p>
          <ol className="space-y-3">
            {NOTES.map(([title, body], i) => (
              <li key={title} className="flex gap-3">
                <span className="flex-none font-mono text-[11px] font-bold text-coral">{String(i + 1).padStart(2, "0")}</span>
                <div>
                  <p className="text-[13px] font-semibold text-ink">{title}</p>
                  <p className="mt-0.5 font-mono text-[10.5px] leading-relaxed text-mut">{body}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
