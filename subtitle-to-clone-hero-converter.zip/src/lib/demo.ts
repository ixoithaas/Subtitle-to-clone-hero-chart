/** Original demo lyrics (fictional song "Neon Meridian" by Paper Satellites). */

export const DEMO_SRT = `1
00:00:08,000 --> 00:00:11,500
Streetlights flicker on the interstate

2
00:00:11,600 --> 00:00:15,000
We chase the static through the midnight gate

3
00:00:15,100 --> 00:00:18,800
Radio humming a hollow tune

4
00:00:18,900 --> 00:00:22,500
Paper airplanes crossing the moon

5
00:00:30,000 --> 00:00:33,500
Hold the signal,
hold it high

6
00:00:33,600 --> 00:00:37,000
We are sparks in a velvet sky

7
00:00:37,100 --> 00:00:40,800
Every syllable a little flame

8
00:00:40,900 --> 00:00:44,500
Burning every letter of your name

9
00:00:52,000 --> 00:00:55,500
Neon meridian, guide us home

10
00:00:55,600 --> 00:00:59,200
Down the highway of the unknown
`;

export const DEMO_LRC = `[ar:Paper Satellites]
[ti:Neon Meridian]
[al:Syllabox Demo EP]
[by:Syllabox]
[offset:0]
[00:08.00]Streetlights flicker on the interstate
[00:11.60]We chase the static through the midnight gate
[00:15.10]Radio humming a hollow tune
[00:18.90]Paper airplanes crossing the moon
[00:30.00]<00:30.00>Hold <00:30.45>the <00:30.80>sig<00:31.20>nal, <00:31.90>hold <00:32.30>it <00:32.70>high
[00:33.60]We are sparks in a velvet sky
[00:37.10][01:05.10]Every syllable a little flame
[00:40.90]Burning every letter of your name
[00:52.00]Neon meridian, guide us home
[00:55.60]Down the highway of the unknown
`;
