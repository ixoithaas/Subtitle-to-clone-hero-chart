import type { AnchorEvent, TempoEvent } from "./types";

export type { TempoEvent, AnchorEvent };

/** time signature marker: TS 4000 = 4/4, TS 3000 3 = 3/8 */
export interface MeterEvent {
  tick: number;
  numerator: number;
  denominator: number;
}

export interface ImportedChartEvent {
  tick: number;
  type: string;
  payload: string;
}

export interface ImportedChart {
  fileName: string;
  song: Record<string, string>;
  name?: string;
  artist?: string;
  charter?: string;
  resolution: number;
  delaySec: number;
  previewStartMs: number;
  songLengthMs: number;
  tempos: TempoEvent[];
  meters: MeterEvent[];
  anchors: AnchorEvent[];
  events: ImportedChartEvent[];
  lyricCount: number;
  sectionCount: number;
  firstTick: number;
  lastTick: number;
  noteCounts: { section: string; notes: number }[];
  sectionsFound: string[];
  warnings: string[];
}

const ENTRY = /^\s*(\d+)\s*=\s*(.+?)\s*$/;
const NOTE_SECTION = /^(Easy|Medium|Hard|Expert|ExpertPlus)(Single|Double[A-Za-z]*|Drums[A-Za-z]*|GHL[A-Za-z]*)?$/i;

type TempoConv = "milli" | "centi" | "raw";

/** length in ms of tick 0..lastTick under a candidate tempo map */
function mapLengthMs(map: TempoEvent[], resolution: number, lastTick: number): number {
  if (lastTick <= 0 || map.length === 0) return 0;
  let cursorTick = 0;
  let ms = 0;
  for (let k = 0; k < map.length; k++) {
    const nextTick = k + 1 < map.length ? Math.max(map[k + 1].tick, cursorTick) : lastTick;
    ms += (nextTick - cursorTick) * (60000 / (map[k].bpm * resolution));
    cursorTick = nextTick;
    if (cursorTick >= lastTick) break;
  }
  return ms;
}

/**
 * Resolve which unit a set of tempo values uses. Standard .chart (as written
 * by Moonscraper and read by Clone Hero) is milli-BPM, so that is the prior:
 * it stands unless the file's own geometry disproves it — a declared
 * Song Length, or the span implied by the last tick falling outside any
 * plausible song duration.
 */
function interpretTempos(
  rawValues: { tick: number; value: number }[],
  resolution: number,
  declaredLengthMs: number,
  lastTick: number,
): { tempos: TempoEvent[]; conv: TempoConv } {
  const sorted = rawValues
    .filter((r) => Number.isFinite(r.value) && r.value > 0)
    .sort((a, b) => a.tick - b.tick);
  if (sorted.length === 0) return { tempos: [], conv: "milli" };

  const maps: Record<TempoConv, TempoEvent[]> = {
    milli: sorted.map((r) => ({ tick: r.tick, bpm: r.value / 1000 })),
    centi: sorted.map((r) => ({ tick: r.tick, bpm: r.value / 100 })),
    raw: sorted.map((r) => ({ tick: r.tick, bpm: r.value })),
  };
  const lengthOf = (conv: TempoConv): number | null =>
    lastTick > 0 ? mapLengthMs(maps[conv], resolution, lastTick) : null;
  const plausible = (len: number | null): boolean =>
    len === null || !Number.isFinite(len) || (len >= 30000 && len <= 1200000);

  // 1. a declared Song Length is decisive evidence
  if (declaredLengthMs > 0 && lastTick > 0) {
    let best: TempoConv | null = null;
    let bestRel = Infinity;
    for (const conv of ["milli", "centi", "raw"] as TempoConv[]) {
      const len = lengthOf(conv);
      if (len && len > 0) {
        const rel = Math.abs(len - declaredLengthMs) / declaredLengthMs;
        if (rel < bestRel) {
          bestRel = rel;
          best = conv;
        }
      }
    }
    if (best && bestRel < 0.25) return { tempos: maps[best], conv: best };
  }

  // 2. standard milli-BPM stands unless the geometry disproves it
  if (plausible(lengthOf("milli"))) return { tempos: maps.milli, conv: "milli" };

  // 3. non-standard writers: BPM×100, then plain BPM
  for (const conv of ["centi", "raw"] as TempoConv[]) {
    if (plausible(lengthOf(conv))) return { tempos: maps[conv], conv };
  }
  return { tempos: maps.milli, conv: "milli" };
}

function unquote(s: string): string {
  const t = s.trim();
  if (t.length >= 2 && t.startsWith('"') && t.endsWith('"')) return t.slice(1, -1);
  return t;
}

function unescape(s: string): string {
  return s.replace(/\\(.)/g, "$1");
}

export function parseChartFile(text: string, fileName: string): ImportedChart {
  // expand single-line braces ("{ Name = \"x\" }") into normal block lines
  const lines: string[] = [];
  for (const raw of text.replace(/\r\n?/g, "\n").split("\n")) {
    const t = raw.trim();
    const inline = t.match(/^\{(.+)\}$/);
    if (inline) {
      lines.push("{", inline[1].trim(), "}");
    } else if (t.startsWith("{") && t.length > 1) {
      lines.push("{", t.slice(1).trim()); // "{0 = B 120000" — opening brace with content
    } else {
      lines.push(raw);
    }
  }
  const song: Record<string, string> = {};
  const meters: MeterEvent[] = [];
  const anchors: AnchorEvent[] = [];
  const events: ImportedChartEvent[] = [];
  const noteCounts: { section: string; notes: number }[] = [];
  const sectionsFound: string[] = [];
  const warnings: string[] = [];

  let section: string | null = null;
  let inBrace = false;
  let noteSection: string | null = null;
  let noteCount = 0;
  const rawB: { tick: number; value: number }[] = [];
  const rawTS: { tick: number; value: number }[] = [];
  let maxTick = 0;

  for (const raw of lines) {
    const line = raw.trim();
    if (!line || line.startsWith("//") || line.startsWith(";")) continue;

    const sec = line.match(/^\[([A-Za-z0-9_ ]+)\]$/);
    if (sec) {
      section = sec[1];
      sectionsFound.push(section);
      inBrace = false;
      continue;
    }
    if (line === "{") {
      inBrace = true;
      if (section && NOTE_SECTION.test(section)) {
        noteSection = section;
        noteCount = 0;
      }
      continue;
    }
    if (line === "}") {
      if (noteSection) noteCounts.push({ section: noteSection, notes: noteCount });
      noteSection = null;
      inBrace = false;
      continue;
    }
    if (!section || !inBrace || noteSection) {
      if (noteSection && ENTRY.test(line)) noteCount++;
      continue;
    }

    if (section === "Song") {
      const kv = line.match(/^([^=]+?)\s*=\s*(.*)$/);
      if (kv) song[kv[1].trim()] = unquote(kv[2]);
      continue;
    }

    const entry = line.match(ENTRY);
    if (!entry) continue;
    const tick = parseInt(entry[1], 10);
    const val = entry[2];
    maxTick = Math.max(maxTick, tick);

    if (section === "SyncTrack") {
      // [SyncTrack] as Clone Hero / Moonscraper implement it:
      //   B <bpm×1000>      tempo
      //   TS <num×1000> [log2(den)]   time signature (TS 4000 = 4/4)
      //   A <µs>            anchor — absolute time in microseconds
      const parts = val.split(/\s+/);
      const type = parts[0].toUpperCase();
      if (type === "B" && parts[1] !== undefined) {
        const v = parseFloat(parts[1]);
        if (Number.isFinite(v)) rawB.push({ tick, value: v });
      } else if (type === "TS" && parts[1] !== undefined) {
        const num = parseFloat(parts[1]);
        if (Number.isFinite(num)) {
          const denExp = parts[2] !== undefined ? parseInt(parts[2], 10) : NaN;
          meters.push({
            tick,
            numerator: num / 1000,
            denominator: Number.isFinite(denExp) ? Math.pow(2, denExp) : 4,
          });
        }
        rawTS.push({ tick, value: num }); // fallback tempo source, see below
      } else if (type === "A" && parts[1] !== undefined) {
        const v = parseFloat(parts[1]);
        if (Number.isFinite(v) && v >= 0) anchors.push({ tick, timeMs: v / 1000 });
      }
      continue;
    }

    if (section === "Events") {
      const em = val.match(/^E\s+"((?:[^"\\]|\\)*)"\s*(.*)$/);
      if (!em) continue;
      const type = unescape(em[1]);
      const rest = em[2].trim();
      const pm = rest.match(/^"((?:[^"\\]|\\.)*)"/);
      events.push({ tick, type, payload: pm ? unescape(pm[1]) : "" });
      continue;
    }
  }

  if (
    Object.keys(song).length === 0 &&
    rawB.length === 0 &&
    rawTS.length === 0 &&
    events.length === 0
  ) {
    throw new Error(
      'No recognizable .chart content — expected sections like [Song], [SyncTrack] or [Events].',
    );
  }

  const resolution = parseInt(song["Resolution"] ?? "", 10) || 192;
  const delaySec = parseFloat(song["Delay"] ?? "0") || 0;
  const previewStartMs = parseInt(song["PreviewStart"] ?? "0", 10) || 0;
  const rawLength = parseInt(song["Song Length"] ?? "0", 10) || 0;
  // some files declare the length in whole seconds
  const songLengthMs = rawLength > 0 && rawLength < 2000 ? rawLength * 1000 : rawLength;

  // tempos live in B markers; TS markers are time signatures
  const primary = interpretTempos(rawB, resolution, songLengthMs, maxTick);
  let tempos = primary.tempos;
  let conv: TempoConv = primary.conv;
  let tempoFromTS = false;
  if (tempos.length === 0 && rawTS.length > 0) {
    // a chart with TS markers but no B markers: per the Moonscraper/CH
    // format those are time signatures, not tempos — but some non-standard
    // converters wrote tempo into TS, so check the geometry before deciding.
    const asTempo = interpretTempos(rawTS, resolution, songLengthMs, maxTick);
    const standardLen = maxTick > 0 ? mapLengthMs(asTempo.tempos, resolution, maxTick) : null;
    // only accept TS-as-tempo when the geometry fits AND the result is a
    // musical tempo — otherwise it's far more likely a plain time signature
    const musical = asTempo.tempos.every((t) => t.bpm >= 20 && t.bpm <= 400);
    if (standardLen !== null && standardLen >= 30000 && standardLen <= 1200000 && musical) {
      tempos = asTempo.tempos;
      conv = asTempo.conv;
      tempoFromTS = true;
    }
  }

  events.sort((a, b) => a.tick - b.tick);
  anchors.sort((a, b) => a.tick - b.tick);

  const lyricCount = events.filter((e) => e.type === "lyric").length;
  const sectionCount = events.filter((e) => e.type === "section").length;

  if (tempoFromTS) {
    warnings.push(
      "No B tempo markers found — this chart stores tempo in TS events (a non-standard convention; TS is normally the time signature). Values were interpreted as tempo; verify against the audio.",
    );
  } else if (tempos.length === 0) {
    warnings.push(
      "No tempo (B) markers in [SyncTrack] — BPM left unchanged. TS markers were read as time signatures.",
    );
  }
  if (conv === "centi") {
    warnings.push(
      "Non-standard tempo values — read as BPM×100 (e.g. B 4000 → 40 BPM), the only convention matching this chart's length. Verify sync against the audio.",
    );
  } else if (conv === "raw") {
    warnings.push(
      "Non-standard tempo values — read as plain BPM (e.g. B 128.5). Verify sync against the audio.",
    );
  }
  if (conv === "milli" && tempos.some((t) => t.bpm < 20 || t.bpm > 400)) {
    warnings.push(
      `Unusual tempo value read as standard milli-BPM (${tempos.map((t) => t.bpm).join(" → ")} BPM). If this is a sync-hack chart the tempo map will still convert ticks correctly.`,
    );
  }
  if (anchors.length > 0) {
    warnings.push(
      `${anchors.length} anchor (A) marker${anchors.length > 1 ? "s" : ""} imported — tick conversion pins to them, and they are re-exported into generated charts.`,
    );
  }
  if (tempos.length > 1) {
    warnings.push(
      `Full tempo map imported (${tempos.length} markers: ${tempos
        .slice(0, 4)
        .map((t) => `${t.bpm} @${t.tick}`)
        .join(", ")}${tempos.length > 4 ? ", …" : ""}). Tick conversion follows every change.`,
    );
  }
  if (delaySec !== 0) {
    warnings.push(
      `Delay ${delaySec}s applied as offset ${Math.round(-delaySec * 1000)} ms (audio 0:00 lands at chart time ${delaySec}s).`,
    );
  }

  return {
    fileName,
    song,
    name: song["Name"] || undefined,
    artist: song["Artist"] || undefined,
    charter: song["Charter"] || undefined,
    resolution,
    delaySec,
    previewStartMs,
    songLengthMs,
    tempos,
    meters,
    anchors,
    events,
    lyricCount,
    sectionCount,
    firstTick: events.length ? events[0].tick : 0,
    lastTick: events.length ? events[events.length - 1].tick : 0,
    noteCounts,
    sectionsFound,
    warnings,
  };
}
