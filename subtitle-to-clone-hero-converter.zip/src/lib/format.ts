/** 00:12.345 (or 1:02:03.456 when over an hour) */
export function fmtTime(ms: number): string {
  const neg = ms < 0;
  const t = Math.abs(Math.round(ms));
  const h = Math.floor(t / 3600000);
  const m = Math.floor((t % 3600000) / 60000);
  const s = Math.floor((t % 60000) / 1000);
  const cs = Math.floor((t % 1000) / 10);
  const mm = h > 0 ? String(m).padStart(2, "0") : String(m);
  const core = `${h > 0 ? h + ":" : ""}${mm}:${String(s).padStart(2, "0")}.${String(cs).padStart(2, "0")}`;
  return neg ? `-${core}` : core;
}

/** 00:12 */
export function fmtClock(ms: number): string {
  const t = Math.max(0, Math.round(ms));
  const m = Math.floor(t / 60000);
  const s = Math.floor((t % 60000) / 1000);
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function fmtTick(tick: number): string {
  return tick.toLocaleString("en-US");
}

export function clamp(v: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, v));
}
