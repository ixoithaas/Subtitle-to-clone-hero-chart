import type { RawLine, SongMeta } from "./types";

export type SubtitleFormat = "srt" | "lrc";

export interface ParseResult {
  format: SubtitleFormat;
  lines: RawLine[];
  meta: SongMeta;
  notes: string[];
}

const SRT_TIME = /^(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})/;

function hms(h: string, m: string, s: string, frac: string): number {
  return (
    parseInt(h, 10) * 3600000 +
    parseInt(m, 10) * 60000 +
    parseInt(s, 10) * 1000 +
    parseInt(frac.padEnd(3, "0").slice(0, 3), 10)
  );
}

export function detectFormat(text: string, fileName?: string): SubtitleFormat | null {
  const ext = fileName?.toLowerCase().match(/\.(srt|lrc|txt)$/)?.[1];
  if (ext === "srt") return "srt";
  if (ext === "lrc") return "lrc";
  if (/\d{1,2}:\d{2}:\d{2}[,.]\d{1,3}\s*-->/.test(text)) return "srt";
  if (/^\s*\[\d{1,2}:\d{2}(?:[.:]\d{1,3})?\]/m.test(text)) return "lrc";
  return null;
}

function stripTags(s: string): string {
  return s
    .replace(/<[^>]*>/g, "")
    .replace(/\{\\[^}]*\}/g, "") // SSA-style override blocks, just in case
    .replace(/\s+/g, " ")
    .trim();
}

/* ------------------------------------------------------------------ */
/* SRT                                                                 */
/* ------------------------------------------------------------------ */

export function parseSRT(text: string): { lines: RawLine[]; notes: string[] } {
  const notes: string[] = [];
  const normalized = text.replace(/\r\n?/g, "\n").replace(/^\uFEFF/, "");
  const blocks = normalized.split(/\n{2,}/);
  const lines: RawLine[] = [];

  for (const rawBlock of blocks) {
    const block = rawBlock.trim();
    if (!block) continue;
    const blockLines = block.split("\n").map((l) => l.trim());

    // find the timecode line (skip optional numeric index above it)
    let timeIdx = blockLines.findIndex((l) => SRT_TIME.test(l));
    if (timeIdx === -1) continue;

    const m = blockLines[timeIdx].match(SRT_TIME)!;
    const startMs = hms(m[1], m[2], m[3], m[4]);
    const endMs = hms(m[5], m[6], m[7], m[8]);

    const text = stripTags(blockLines.slice(timeIdx + 1).join(" "));
    if (!text) {
      notes.push(`Cue at ${Math.round(startMs / 10) / 100}s had no text — skipped.`);
      continue;
    }
    lines.push({ id: `r${lines.length}`, index: lines.length, startMs, endMs, text });
  }

  lines.sort((a, b) => a.startMs - b.startMs);
  lines.forEach((l, i) => {
    l.index = i;
    l.id = `r${i}`;
  });
  return { lines, notes };
}

/* ------------------------------------------------------------------ */
/* LRC (classic + enhanced word timestamps)                            */
/* ------------------------------------------------------------------ */

const LRC_META = /^\s*\[(ar|ti|al|by|offset|re|ve|length|au)\s*:\s*(.*?)\]\s*$/i;
const LRC_TIME = /\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?\]/g;
const LRC_WORD_TIME = /<(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?>/g;

function mmss(m: string, s: string, frac?: string): number {
  const f = frac ? parseInt(frac.padEnd(3, "0").slice(0, 3), 10) : 0;
  return parseInt(m, 10) * 60000 + parseInt(s, 10) * 1000 + f;
}

export function parseLRC(text: string): { lines: RawLine[]; meta: SongMeta; notes: string[] } {
  const notes: string[] = [];
  const meta: SongMeta = {};
  const normalized = text.replace(/\r\n?/g, "\n").replace(/^\uFEFF/, "");
  const entries: { startMs: number; words: { t: number | null; text: string }[] }[] = [];
  let offsetMs = 0;

  for (const rawLine of normalized.split("\n")) {
    const line = rawLine.trim();
    if (!line) continue;

    const metaMatch = line.match(LRC_META);
    if (metaMatch) {
      const key = metaMatch[1].toLowerCase();
      const val = metaMatch[2].trim();
      if (key === "ar") meta.artist = val;
      else if (key === "ti") meta.title = val;
      else if (key === "al") meta.album = val;
      else if (key === "by") meta.creator = val;
      else if (key === "offset") {
        const v = parseInt(val.replace(/^\+/, ""), 10);
        if (!Number.isNaN(v)) offsetMs = v;
      }
      continue;
    }

    // collect all leading [mm:ss.xx] stamps (repeated-chorus syntax)
    const stamps: number[] = [];
    let lastIdx = 0;
    LRC_TIME.lastIndex = 0;
    let tm: RegExpExecArray | null;
    while ((tm = LRC_TIME.exec(line)) !== null) {
      stamps.push(mmss(tm[1], tm[2], tm[3]));
      lastIdx = LRC_TIME.lastIndex;
      // only contiguous leading stamps belong to the timestamp group
      const rest = line.slice(lastIdx).trimStart();
      if (!rest.startsWith("[")) break;
    }
    if (stamps.length === 0) continue; // stray text line

    const body = line.slice(lastIdx).trim();

    // enhanced word timestamps: <mm:ss.xx>word
    const words: { t: number | null; text: string }[] = [];
    const head = body.split(LRC_WORD_TIME)[0];
    if (head.trim()) words.push({ t: null, text: head });
    const parts = body.split(LRC_WORD_TIME);
    // split with capture groups: [head, m,s,f, seg, m,s,f, seg, ...]
    for (let i = 1; i < parts.length; i += 4) {
      const t = mmss(parts[i], parts[i + 1], parts[i + 2]);
      const seg = parts[i + 3] ?? "";
      if (seg.trim()) words.push({ t, text: seg });
    }
    if (words.length === 0) words.push({ t: null, text: body });
    if (!words.map((w) => w.text).join("").trim()) continue;

    for (const stamp of stamps) {
      entries.push({ startMs: stamp, words: words.map((w) => ({ ...w })) });
    }
  }

  entries.sort((a, b) => a.startMs - b.startMs);

  const lines: RawLine[] = entries.map((e, i) => {
    // rebuild the plain text: segments carry their own whitespace (enhanced
    // LRC tags replace the spaces they sit at), so join verbatim.
    const text = e.words.map((w) => w.text).join("").replace(/\s+/g, " ").trim();
    return { id: `r${i}`, index: i, startMs: e.startMs - offsetMs, endMs: null, text };
  });

  // stash segment timings (null time = untimed head segment, kept so the
  // syllabifier's letter cursor stays aligned), keyed by line id.
  wordTimeCache = new Map(
    entries.map((e, i) => [
      `r${i}`,
      e.words.map((w) => ({ startMs: w.t === null ? null : w.t - offsetMs, text: w.text })),
    ]),
  );

  if (offsetMs !== 0) notes.push(`Applied LRC [offset:${offsetMs}] tag to every timestamp.`);
  const withWords = [...wordTimeCache.values()].filter((w) => w.length > 0).length;
  if (withWords > 0) notes.push(`${withWords} line(s) carried enhanced <mm:ss.xx> word timestamps — used as syllable anchors.`);

  return { lines, meta, notes };
}

export type WordTime = { startMs: number | null; text: string };
let wordTimeCache: Map<string, WordTime[]> = new Map();
export function takeWordTimes(): Map<string, WordTime[]> {
  const m = wordTimeCache;
  wordTimeCache = new Map();
  return m;
}

/* ------------------------------------------------------------------ */

export function parseSubtitleFile(text: string, fileName?: string): ParseResult {
  const format = detectFormat(text, fileName);
  if (!format) {
    throw new Error("Could not detect SRT or LRC syntax. Check the file contains timecodes like 00:00:12,000 --> or [00:12.00].");
  }
  if (format === "srt") {
    const { lines, notes } = parseSRT(text);
    if (lines.length === 0) throw new Error("No valid SRT cues found (expected blocks of “index / timecode --> timecode / text”).");
    return { format, lines, meta: {}, notes };
  }
  const { lines, meta, notes } = parseLRC(text);
  if (lines.length === 0) throw new Error("No timed LRC lines found (expected [mm:ss.xx] at the start of lyric lines).");
  return { format, lines, meta, notes };
}
