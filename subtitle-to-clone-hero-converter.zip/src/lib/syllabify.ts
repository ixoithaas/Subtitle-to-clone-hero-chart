import Hypher from "hypher";
import enUs from "hyphenation.en-us";
import type { LyricLine, RawLine, Settings, Syllable, Word } from "./types";
import type { WordTime } from "./parsers";

const hypher = new Hypher(enUs);

/**
 * Split a single word into syllable chunks.
 *  - explicit hyphens in the source text always break ("heart-broken")
 *  - TeX en-US hyphenation patterns break the rest where possible
 *  - leading/trailing punctuation stays glued to its chunk
 */
export function splitWord(word: string): string[] {
  const lead = word.match(/^[^A-Za-z\u00C0-\u024F'’-]*/)?.[0] ?? "";
  const trail = word.match(/[^A-Za-z\u00C0-\u024F'’-]*$/)?.[0] ?? "";
  const core = word.slice(lead.length, word.length - trail.length || undefined);
  if (!core) return [word];

  const pieces: string[] = [];
  for (const part of core.split("-").filter(Boolean)) {
    const pure = part.replace(/['’]/g, "");
    if (pure.length >= 4) {
      try {
        const chunks = hypher.hyphenate(part);
        if (chunks.length > 0) {
          pieces.push(...chunks.filter(Boolean));
          continue;
        }
      } catch {
        /* fall through to unsplit */
      }
    }
    pieces.push(part);
  }

  const out = pieces.length > 0 ? pieces : [core];
  out[0] = lead + out[0];
  out[out.length - 1] = out[out.length - 1] + trail;
  return out;
}

interface TimedSyllablePlan {
  chunks: { text: string; weight: number }[];
  /** per-word syllable counts, to rebuild word boundaries */
  wordLens: number[];
  wordTexts: string[];
}

function planFromTokens(tokens: string[], distMode: Settings["distMode"]): TimedSyllablePlan {
  const chunks: TimedSyllablePlan["chunks"] = [];
  const wordLens: number[] = [];
  const wordTexts: string[] = [];
  for (const token of tokens) {
    const syls = splitWord(token);
    wordLens.push(syls.length);
    wordTexts.push(token);
    for (const s of syls) {
      const letters = (s.replace(/[^A-Za-z\u00C0-\u024F]/g, "").length) || 1;
      chunks.push({ text: s, weight: distMode === "chars" ? letters : 1 });
    }
  }
  return { chunks, wordLens, wordTexts };
}

const LETTERS = /[a-z'\u00C0-\u024F]/gi;
const letterCount = (s: string) => (s.match(LETTERS) ?? []).length;

function distribute(
  plan: TimedSyllablePlan,
  lineStart: number,
  lineEnd: number,
  anchors?: WordTime[],
): Word[] {
  const totalW = plan.chunks.reduce((a, c) => a + c.weight, 0) || 1;
  const dur = Math.max(lineEnd - lineStart, 240);

  // syllable start times — proportional over the line, then snapped to any
  // enhanced-LRC <mm:ss.xx> anchors via letter-cursor alignment (works for
  // both word-level and syllable-level tags).
  const starts: number[] = [];
  let cum = 0;
  for (const c of plan.chunks) {
    starts.push(lineStart + dur * (cum / totalW));
    cum += c.weight;
  }

  const words: Word[] = [];
  let pos = 0;
  plan.wordLens.forEach((len, wi) => {
    const syls: Syllable[] = [];
    for (let k = 0; k < len; k++) {
      const chunk = plan.chunks[pos];
      syls.push({
        id: `w${wi}s${k}`,
        text: chunk.text,
        startMs: Math.round(starts[pos]),
      });
      pos++;
    }
    words.push({ text: plan.wordTexts[wi], startMs: syls[0].startMs, endMs: lineEnd, syllables: syls });
  });

  // snap anchored syllables: map every letter of the line to its syllable,
  // then walk the anchor segments in reading order.
  if (anchors && anchors.length > 0) {
    const flat = words.flatMap((w) => w.syllables);
    const letterMap: number[] = [];
    flat.forEach((s, si) => {
      const n = letterCount(s.text);
      for (let i = 0; i < n; i++) letterMap.push(si);
    });
    let cursor = 0;
    for (const a of anchors) {
      const n = letterCount(a.text);
      if (n === 0) continue;
      if (a.startMs !== null && cursor < letterMap.length) {
        const target = flat[letterMap[cursor]];
        target.startMs = Math.round(Math.min(Math.max(a.startMs, lineStart), lineEnd));
      }
      cursor = Math.min(cursor + n, letterMap.length);
    }
  }

  // word end = next word start (last word ends at line end)
  for (let i = 0; i < words.length - 1; i++) words[i].endMs = words[i + 1].startMs;

  // enforce monotonic syllable times
  words.forEach((w) => {
    for (let i = 1; i < w.syllables.length; i++) {
      if (w.syllables[i].startMs <= w.syllables[i - 1].startMs) {
        w.syllables[i].startMs = w.syllables[i - 1].startMs + 1;
      }
    }
  });
  return words;
}

/**
 * Turn raw cues into fully-timed lyric lines.
 * `overrides` holds hand-edited syllable texts keyed by raw line id.
 */
export function buildLyricLines(
  rawLines: RawLine[],
  settings: Settings,
  overrides: Map<string, string>,
  removed: Set<string>,
  wordTimes: Map<string, WordTime[]>,
): LyricLine[] {
  const kept = rawLines.filter((r) => !removed.has(r.id) && r.text.trim().length > 0);
  const out: LyricLine[] = [];

  kept.forEach((raw, i) => {
    const next = kept[i + 1];
    let endMs: number;
    if (raw.endMs !== null) {
      endMs = raw.endMs;
    } else if (next && next.startMs - raw.startMs <= settings.holdMs) {
      endMs = next.startMs;
    } else {
      endMs = raw.startMs + settings.holdMs;
    }
    if (endMs - raw.startMs < 240) endMs = raw.startMs + 240;

    const text = overrides.get(raw.id) ?? raw.text;
    const tokens = text.split(/\s+/).filter(Boolean);
    const plan = planFromTokens(tokens, settings.distMode);
    const anchors = overrides.has(raw.id) ? undefined : wordTimes.get(raw.id);
    const words = distribute(plan, raw.startMs, endMs, anchors);

    out.push({
      id: raw.id,
      index: i,
      startMs: raw.startMs,
      endMs,
      text,
      words,
      custom: overrides.has(raw.id),
    });
  });

  return out;
}

/** words → editable string with explicit hyphen split points */
export function lineToHyphenText(line: LyricLine): string {
  return line.words.map((w) => w.syllables.map((s) => s.text).join("-")).join(" ");
}
