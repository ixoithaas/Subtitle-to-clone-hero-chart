import type { AnchorEvent, ChartEvent, ChartResult, LyricLine, Settings, SongMeta, TempoEvent } from "./types";
import type { ImportedChart } from "./chartImport";

type TempoSettings = Pick<Settings, "offsetMs" | "bpm" | "resolution" | "tempoMap" | "anchors">;

function activeMap(s: TempoSettings): TempoEvent[] | null {
  if (!s.tempoMap || s.tempoMap.length === 0) return null;
  const clean = s.tempoMap
    .filter((t) => Number.isFinite(t.bpm) && t.bpm > 0)
    .sort((a, b) => a.tick - b.tick);
  return clean.length > 0 ? clean : null;
}

function activeAnchors(s: TempoSettings): AnchorEvent[] | null {
  if (!s.anchors || s.anchors.length === 0) return null;
  const clean = s.anchors
    .filter((a) => Number.isFinite(a.tick) && Number.isFinite(a.timeMs))
    .sort((a, b) => a.tick - b.tick);
  return clean.length > 0 ? clean : null;
}

/**
 * subtitle ms → chart ticks, walking the sync track the way Clone Hero does:
 * B markers set the tempo for the ticks that follow (first one covers tick 0),
 * A markers pin a tick to an absolute song time. Times that fall inside an
 * anchor's discontinuity gap clamp to the anchor tick.
 */
export function msToTick(ms: number, s: TempoSettings): number {
  const rel = ms - s.offsetMs;
  const map = activeMap(s);
  const anchors = activeAnchors(s);
  if (!map && !anchors) return Math.round((rel / 60000) * s.bpm * s.resolution);

  // start from the last anchor at or before the queried time
  let cursorTick = 0;
  let cursorMs = 0;
  let ti = 0; // tempo index
  if (anchors) {
    for (let i = 0; i < anchors.length; i++) {
      if (anchors[i].timeMs <= rel) {
        cursorTick = anchors[i].tick;
        cursorMs = anchors[i].timeMs;
      } else break;
    }
  }
  // tempo in effect at the cursor
  let bpm = s.bpm;
  if (map) {
    while (ti < map.length && map[ti].tick <= cursorTick) {
      bpm = map[ti].bpm;
      ti++;
    }
  }
  let ai = 0; // anchor index
  if (anchors) {
    while (ai < anchors.length && anchors[ai].tick <= cursorTick) ai++;
  }

  for (;;) {
    const nextTempoTick = map && ti < map.length ? map[ti].tick : Number.POSITIVE_INFINITY;
    const nextAnchorTick = anchors && ai < anchors.length ? anchors[ai].tick : Number.POSITIVE_INFINITY;
    const nextTick = Math.min(nextTempoTick, nextAnchorTick);
    const msPerTick = 60000 / (bpm * s.resolution);
    if (nextTick === Number.POSITIVE_INFINITY) {
      return Math.round(cursorTick + (rel - cursorMs) / msPerTick);
    }
    const nextMs = cursorMs + (nextTick - cursorTick) * msPerTick;
    if (rel < nextMs) {
      return Math.round(cursorTick + (rel - cursorMs) / msPerTick);
    }
    const anchorIsNext = nextAnchorTick <= nextTempoTick;
    if (anchorIsNext && anchors) {
      if (rel < anchors[ai].timeMs) {
        // query sits inside the time gap the anchor jumps over — clamp to it
        return Math.round(anchors[ai].tick);
      }
      cursorTick = anchors[ai].tick;
      cursorMs = anchors[ai].timeMs;
      ai++;
    } else if (map) {
      cursorTick = nextTick;
      cursorMs = nextMs;
      bpm = map[ti].bpm;
      ti++;
    }
  }
}

/** chart ticks → subtitle ms (inverse of msToTick). */
export function tickToMs(tick: number, s: TempoSettings): number {
  const map = activeMap(s);
  const anchors = activeAnchors(s);
  if (!map && !anchors) return s.offsetMs + tick / ((s.bpm / 60000) * s.resolution);

  let cursorTick = 0;
  let cursorMs = 0;
  let bpm = s.bpm;
  let ti = 0;
  let ai = 0;
  if (anchors) {
    for (let i = 0; i < anchors.length; i++) {
      if (anchors[i].tick <= tick) {
        cursorTick = anchors[i].tick;
        cursorMs = anchors[i].timeMs;
        ai = i + 1;
      } else break;
    }
  }
  if (map) {
    while (ti < map.length && map[ti].tick <= cursorTick) {
      bpm = map[ti].bpm;
      ti++;
    }
  }
  for (;;) {
    const nextTempoTick = map && ti < map.length ? map[ti].tick : Number.POSITIVE_INFINITY;
    const nextAnchorTick = anchors && ai < anchors.length ? anchors[ai].tick : Number.POSITIVE_INFINITY;
    const nextTick = Math.min(nextTempoTick, nextAnchorTick);
    const msPerTick = 60000 / (bpm * s.resolution);
    if (tick < nextTick || nextTick === Number.POSITIVE_INFINITY) {
      return s.offsetMs + cursorMs + (tick - cursorTick) * msPerTick;
    }
    if (nextAnchorTick <= nextTempoTick && anchors) {
      cursorTick = anchors[ai].tick;
      cursorMs = anchors[ai].timeMs;
      ai++;
    } else if (map) {
      cursorMs += (nextTick - cursorTick) * msPerTick;
      cursorTick = nextTick;
      bpm = map[ti].bpm;
      ti++;
    }
  }
}

/** tempo in effect at a given subtitle time (first marker covers tick 0). */
export function bpmAtMs(ms: number, s: TempoSettings): number {
  const map = activeMap(s);
  if (!map) return s.bpm;
  const tick = msToTick(ms, s);
  let bpm = map[0].bpm;
  for (const t of map) {
    if (t.tick <= tick) bpm = t.bpm;
    else break;
  }
  return bpm;
}

function esc(text: string): string {
  return text.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}

export function buildChart(
  lines: LyricLine[],
  settings: Settings,
  meta: SongMeta,
  sourceName: string,
  imported?: ImportedChart | null,
): ChartResult {
  const events: ChartEvent[] = [];
  const warnings: string[] = [];
  let clamped = 0;
  let sectionN = 0;

  lines.forEach((line, i) => {
    // section markers
    if (settings.sections && i % settings.sectionEvery === 0) {
      sectionN++;
      const tick = Math.max(0, msToTick(line.startMs, settings));
      events.push({ tick, kind: "section", text: `Section ${sectionN}` });
    }

    const allSyls = line.words.flatMap((w) => w.syllables);
    allSyls.forEach((syl, si) => {
      const word = line.words.find((w) => w.syllables.includes(syl))!;
      const wi = line.words.indexOf(word);
      const isFirstOfWord = word.syllables[0].id === syl.id;
      const isLastOfLine = si === allSyls.length - 1;

      let text: string;
      if (isFirstOfWord) {
        text = (wi > 0 ? " " : "") + syl.text;
      } else {
        text = (settings.hyphenCont ? "-" : "") + syl.text;
      }
      if (isLastOfLine && settings.holdPlus) text += "+";

      let tick = msToTick(syl.startMs, settings);
      if (tick < 0) {
        tick = 0;
        clamped++;
      }
      events.push({ tick, kind: "lyric", text });
    });
  });

  if (clamped > 0) {
    warnings.push(
      `${clamped} syllable(s) fell before tick 0 (behind the audio offset) and were clamped to 0. Lower the offset or shift the song.`,
    );
  }

  const body = events
    .map((e) => `  ${e.tick} = E "${e.kind === "section" ? "section" : "lyric"}" "${esc(e.text)}"`)
    .join("\n");

  const snippet = `[Events]\n{\n${body}\n}`;

  const songName = meta.title || sourceName.replace(/\.(srt|lrc)$/i, "") || "Untitled Song";
  // [SyncTrack] in the format Clone Hero / Moonscraper actually use:
  // B = tempo (BPM×1000), A = anchor (µs), TS = time signature
  const map = activeMap(settings);
  const anchors = activeAnchors(settings);
  const syncRows: { tick: number; order: number; text: string }[] = [];
  if (map) {
    for (const t of map) syncRows.push({ tick: t.tick, order: 1, text: `  ${t.tick} = B ${Math.round(t.bpm * 1000)}` });
  } else {
    syncRows.push({ tick: 0, order: 1, text: `  0 = B ${Math.round(settings.bpm * 1000)}` });
  }
  if (anchors) {
    for (const a of anchors) syncRows.push({ tick: a.tick, order: 0, text: `  ${a.tick} = A ${Math.round(a.timeMs * 1000)}` });
  }
  const meterRows =
    imported && imported.meters.length > 0
      ? imported.meters.map(
          (m) =>
            `  ${m.tick} = TS ${Math.round(m.numerator * 1000)}${m.denominator !== 4 ? ` ${Math.round(Math.log2(m.denominator))}` : ""}`,
        )
      : ["  0 = TS 4000"];
  const syncBody = [
    ...syncRows.sort((x, y) => x.tick - y.tick || x.order - y.order).map((r) => r.text),
    ...meterRows,
  ].join("\n");
  const full = `[Song]
{
  Name = "${esc(songName)}"
  Artist = "${esc(meta.artist || "Unknown Artist")}"
  Charter = "Syllabox"
  Song Length = ${lines.length ? Math.round(lines[lines.length - 1].endMs) : 0}
  Resolution = ${settings.resolution}
  Player2 = bass
  Difficulty = 0
  PreviewStart = 0
  Icon = ""
  LoadingPhrase = "Lyrics converted with Syllabox"
  Delay = 0
}
[SyncTrack]
{
${syncBody}
}
${snippet}`;

  const firstTick = events.length ? events[0].tick : 0;
  const lastTick = events.length ? events[events.length - 1].tick : 0;

  return { events, snippet, full, warnings, firstTick, lastTick };
}
