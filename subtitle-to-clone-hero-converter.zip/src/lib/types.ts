/** A parsed cue straight from the subtitle file, before syllable splitting. */
export interface RawLine {
  id: string;
  index: number;
  startMs: number;
  /** null when the format carries no end time (plain LRC) — estimated later. */
  endMs: number | null;
  text: string;
}

export interface Syllable {
  id: string;
  text: string;
  startMs: number;
}

export interface Word {
  text: string;
  startMs: number;
  endMs: number;
  syllables: Syllable[];
}

export interface LyricLine {
  id: string;
  index: number;
  startMs: number;
  endMs: number;
  text: string;
  words: Word[];
  /** true when the user hand-edited the syllable splits for this line */
  custom: boolean;
}

export type DistMode = "chars" | "equal";

export interface TempoEvent {
  tick: number;
  bpm: number;
}

/** absolute sync anchor: this tick lands at exactly timeMs in the song */
export interface AnchorEvent {
  tick: number;
  timeMs: number;
}

export interface Settings {
  /** audio offset in ms — tick 0 aligns with this subtitle timestamp */
  offsetMs: number;
  bpm: number;
  /** imported tempo map (B markers) — overrides the constant bpm for tick math */
  tempoMap: TempoEvent[] | null;
  /** imported anchors (A markers) — absolute tick↔time fixes */
  anchors: AnchorEvent[] | null;
  resolution: number;
  /** max line hold (ms) used when a format has no end times */
  holdMs: number;
  distMode: DistMode;
  /** prefix continuation syllables with "-" (Clone Hero joins them) */
  hyphenCont: boolean;
  /** append "+" to the last syllable of each line so it lingers on screen */
  holdPlus: boolean;
  sections: boolean;
  sectionEvery: number;
}

export interface ChartEvent {
  tick: number;
  kind: "lyric" | "section";
  text: string;
}

export interface ChartResult {
  events: ChartEvent[];
  snippet: string;
  full: string;
  warnings: string[];
  firstTick: number;
  lastTick: number;
}

export interface SongMeta {
  artist?: string;
  title?: string;
  album?: string;
  creator?: string;
}
